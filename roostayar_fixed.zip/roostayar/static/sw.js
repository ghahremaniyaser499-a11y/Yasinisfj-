// سرویس‌ورکر روستایار - نصب به عنوان اپلیکیشن و پشتیبانی حالت آفلاین برای فایل‌های ثابت
// نکته‌ی مهم: نسخه‌ی کش (CACHE_NAME) باید با هر تغییر در فایل‌های ثابت (CSS/آیکون‌ها) عوض بشه
// وگرنه کاربرهایی که اپ رو نصب کردن، همیشه نسخه‌ی قدیمیِ کش‌شده رو می‌بینن، نه نسخه‌ی جدید سرور رو.
const CACHE_NAME = 'roostayar-v5';
const STATIC_ASSETS = [
  '/static/css/style.css',
  '/static/icons/icon-192.png',
  '/static/icons/icon-512.png',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(STATIC_ASSETS)).catch(() => {})
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

// استراتژی «شبکه اول» برای فایل‌های ثابت: هر بار اول از سرور نسخه‌ی تازه گرفته میشه و کش
// به‌روزرسانی می‌شود؛ فقط وقتی کاربر آفلاینه (خطای شبکه) از کش قدیمی به‌عنوان جایگزین استفاده می‌شود.
// این‌طوری همیشه آخرین نسخه‌ی CSS/آیکون به کاربر می‌رسد، حتی روی اپ نصب‌شده، بدون نیاز به
// حذف دستی کش توسط کاربر.
self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);
  if (event.request.method !== 'GET') return;
  if (STATIC_ASSETS.some((p) => url.pathname === p)) {
    event.respondWith(
      fetch(event.request)
        .then((res) => {
          const copy = res.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy)).catch(() => {});
          return res;
        })
        .catch(() => caches.match(event.request))
    );
  }
});
