#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
روستایار - بازارچه روستاهای سرخس
نسخه ۵.۰ - سخت‌سازی امنیتی
"""
import os, sqlite3, hashlib, secrets, re, json, time, math, urllib.request, urllib.parse
from datetime import datetime, timedelta
from functools import wraps
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash
from flask import (
    Flask, render_template, request, redirect, url_for,
    flash, session, g, jsonify, abort, send_from_directory
)
import assistant as AST

# بارگذاری متغیرهای محیطی از فایل .env (در صورت وجود) - برای استقرار امن بدون هاردکد کردن رمزها
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

def _load_or_create_secret_key():
    """SECRET_KEY را از متغیر محیطی می‌خواند؛ در غیر این صورت یک کلید ثابت در فایل محلی
    می‌سازد تا نشست‌های کاربران با هر ری‌استارت سرور باطل نشوند (مناسب توسعه محلی).
    برای تولید (production) حتماً SECRET_KEY را در .env تنظیم کنید."""
    env_key = os.environ.get('SECRET_KEY')
    if env_key:
        return env_key
    key_file = os.path.join(BASE_DIR, '.secret_key')
    if os.path.exists(key_file):
        return open(key_file).read().strip()
    new_key = secrets.token_hex(32)
    try:
        with open(key_file, 'w') as f:
            f.write(new_key)
    except OSError:
        pass
    return new_key

IS_PRODUCTION = os.environ.get('FLASK_ENV', 'development') == 'production'

app = Flask(__name__)
app.secret_key = _load_or_create_secret_key()
app.config['MAX_CONTENT_LENGTH'] = 30 * 1024 * 1024  # کل درخواست تا ۳۰ مگابایت (چند عکس با کیفیت دوربین موبایل)
MAX_SINGLE_IMG_MB = 8  # حداکثر حجم هر عکس قبل از فشرده‌سازی سمت سرور
# تنظیمات امن نشست/کوکی
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
app.config['SESSION_COOKIE_SECURE'] = os.environ.get('SESSION_COOKIE_SECURE', 'true' if IS_PRODUCTION else 'false').lower() == 'true'
app.config['PERMANENT_SESSION_LIFETIME'] = 60 * 60 * 24 * 14  # ۱۴ روز

UPLOAD = os.path.join(BASE_DIR, 'static', 'uploads')
CHAT_UPLOAD = os.path.join(UPLOAD, 'chat')
DB = os.path.join(BASE_DIR, 'roostayar.db')
app.config['UPLOAD_FOLDER'] = UPLOAD
app.config['CHAT_UPLOAD_FOLDER'] = CHAT_UPLOAD

IMG_EXT = {'.jpg', '.jpeg', '.png', '.webp'}
CHAT_EXT = IMG_EXT | {'.mp4', '.webm', '.3gp'}

CATEGORIES = {
    'لوازم خانگی': ['یخچال', 'ماشین لباسشویی', 'اجاق گاز', 'جاروبرقی', 'بخاری', 'کولر', 'فریزر', 'سایر'],
    'موبایل و کامپیوتر': ['موبایل', 'تبلت', 'لپ‌تاپ', 'کامپیوتر', 'لوازم جانبی', 'سایر'],
    'خودرو': ['سواری', 'شاسی‌بلند', 'وانت', 'موتورسیکلت', 'سایر'],
    'زمین و مسکن': ['زمین', 'آپارتمان', 'خانه', 'باغ', 'مغازه', 'سایر'],
    'کشاورزی و دام': ['محصولات زراعی', 'میوه', 'سبزیجات', 'دام', 'طیور', 'ابزار', 'سایر'],
    'لوازم شخصی': ['لباس', 'کفش', 'کیف', 'ساعت', 'سایر'],
    'لوازم ورزشی': ['توپ', 'دوچرخه', 'لوازم ورزشی', 'سایر'],
    'ابزار و یراق': ['ابزار دستی', 'ابزار برقی', 'لوله‌کشی', 'سایر'],
    'غذایی': ['خشکبار', 'لبنیات', 'گوشت', 'نان', 'شیرینی', 'سایر'],
    'خدمات': ['نقاشی', 'نجاری', 'برقکاری', 'تعمیرات', 'حمل‌ونقل', 'آموزش', 'سایر'],
    'سایر': []
}

CATEGORY_ICONS = {
    'لوازم خانگی': '🧺', 'موبایل و کامپیوتر': '📱', 'خودرو': '🚗',
    'زمین و مسکن': '🏡', 'کشاورزی و دام': '🐄', 'لوازم شخصی': '👕',
    'لوازم ورزشی': '⚽', 'ابزار و یراق': '🛠️', 'غذایی': '🍞',
    'خدمات': '🧰', 'سایر': '📦',
}
app.jinja_env.globals['cat_icon'] = lambda c: CATEGORY_ICONS.get(c, '📦')

# رنگ اختصاصی هر دسته‌بندی برای نمایش حرفه‌ای‌تر آیکون‌ها در صفحه اصلی
CATEGORY_COLORS = {
    'لوازم خانگی': '#8e44ad', 'موبایل و کامپیوتر': '#e74c3c', 'خودرو': '#2980b9',
    'زمین و مسکن': '#16a085', 'کشاورزی و دام': '#27ae60', 'لوازم شخصی': '#d35400',
    'لوازم ورزشی': '#2c3e50', 'ابزار و یراق': '#7f8c8d', 'غذایی': '#c0392b',
    'خدمات': '#f39c12', 'سایر': '#34495e',
}
app.jinja_env.globals['cat_color'] = lambda c: CATEGORY_COLORS.get(c, '#1a7a3a')

INFO_PAGES = {
    'about': {
        'title': 'درباره روستایار',
        'icon': '🌾',
        'body': [
            'روستایار یک بازارچه محلی آنلاین است که برای خرید و فروش کالا و خدمات میان اهالی روستاها و شهرهای شهرستان سرخس راه‌اندازی شده است.',
            'هدف ما این است که مردم منطقه بدون واسطه و بدون هزینه اضافه، آگهی‌های خود را در معرض دید همسایه‌ها و اهالی روستاهای اطراف قرار دهند.',
            'ثبت آگهی در روستایار همیشه رایگان است.',
        ],
    },
    'rules': {
        'title': 'قوانین و مقررات',
        'icon': '📜',
        'body': [
            'انتشار آگهی برای کالا یا خدمات غیرقانونی ممنوع است.',
            'درج اطلاعات نادرست، گمراه‌کننده یا کلاهبرداری منجر به مسدودشدن حساب کاربری می‌شود.',
            'استفاده از کلمات نامناسب یا توهین‌آمیز در آگهی‌ها مجاز نیست.',
            'هر کاربر مسئول صحت اطلاعاتی است که در آگهی خود درج می‌کند.',
            'روستایار صرفاً محلی برای اتصال خریدار و فروشنده است و در معاملات مسئولیتی ندارد؛ پیش از پرداخت هرگونه وجه، از صحت کالا و طرف معامله اطمینان حاصل کنید.',
        ],
    },
    'faq': {
        'title': 'سوالات متداول',
        'icon': '❓',
        'body': [
            'ثبت‌نام و ثبت آگهی رایگان است؟ بله، کاملاً رایگان.',
            'چطور با فروشنده تماس بگیرم؟ از صفحه آگهی می‌توانید شماره تماس (در صورت نمایش) یا گزینه چت داخل‌برنامه را استفاده کنید.',
            'اگر آگهی نامناسب دیدم چه کنم؟ در صفحه آگهی گزینه «گزارش تخلف» وجود دارد.',
            'رمز عبورم را فراموش کرده‌ام. از صفحه ورود، گزینه «رمز عبور را فراموش کرده‌اید؟» را انتخاب کنید.',
        ],
    },
}
app.jinja_env.globals['info_pages'] = INFO_PAGES

BANNED = [
    'کیر','کوس','کون','جنده','فاحشه','سکس','حشری','پورن',
    'fuck','sex','porn','nude','naked','dick','pussy','slut','whore',
    'bitch','xxx','xnxx','sexy','boobs','cock','cunt',
]

def send_otp_sms(phone, code):
    """ارسال کد OTP از طریق SMS Provider"""
    try:
        from sms_config import ACTIVE_PROVIDER, KAVENEGAR_KEY, SMS_IR_KEY, GHASEDAK_KEY
    except ImportError:
        print(f'[تست] کد OTP براي {phone}: {code}')
        return True
    
    if not ACTIVE_PROVIDER:
        print(f'[تست] کد OTP براي {phone}: {code}')
        return True
    
    try:
        if ACTIVE_PROVIDER == 'kavenegar' and KAVENEGAR_KEY:
            params = urllib.parse.urlencode({
                'receptor': phone, 'token': code,
                'token2': 'روستایار', 'template': 'verify'
            })
            url = f"https://api.kavenegar.com/v1/{KAVENEGAR_KEY}/verify.json?{params}"
            urllib.request.urlopen(url, timeout=10)
            return True
        elif ACTIVE_PROVIDER == 'sms_ir' and SMS_IR_KEY:
            data = json.dumps({"mobile": phone, "templateId": 0,
                "parameters": [{"name": "CODE", "value": code}]}).encode()
            req = urllib.request.Request("https://api.sms.ir/v1/send/verify",
                data=data, headers={'Content-Type': 'application/json',
                'Authorization': SMS_IR_KEY})
            urllib.request.urlopen(req, timeout=10)
            return True
        elif ACTIVE_PROVIDER == 'ghasedak' and GHASEDAK_KEY:
            data = urllib.parse.urlencode({
                'receptor': phone, 'type': '1', 'message': f'کد تأیید روستایار: {code}'
            }).encode()
            req = urllib.request.Request("https://api.ghasedak.me/v2/Message/send",
                data=data, headers={'Content-Type': 'application/x-www-form-urlencoded',
                'apikey': GHASEDAK_KEY})
            urllib.request.urlopen(req, timeout=10)
            return True
    except Exception as e:
        print(f'خطای SMS: {e}')
    
    print(f'[تست] کد OTP براي {phone}: {code}')
    return True

def has_banned(t):
    if not t: return False
    t = t.lower()
    return any(w.lower() in t for w in BANNED)

# ساختار رسمی و کامل تقسیمات روستایی شهرستان سرخس (بر اساس اطلاعات محلی ارائه‌شده)
# هر روستا ذیل بخش و دهستان خودش دسته‌بندی شده تا امکان انتخاب دقیق‌تر فراهم شود
VILLAGE_STRUCTURE = {
    'بخش مرکزی': {
        'دهستان سرخس': [
            'ابراهیم‌آباد', 'امامزاده خواجه', 'تام رسول', 'تام مختار', 'تام میرزاحسن',
            'تپه میراحمد', 'عباس‌آباد', 'حسن‌آباد', 'قوش چاکر', 'قوش خزائی',
            'قوش علیجان', 'قوش کهنه', 'قلعه‌نو', 'کوره برات نیرومند', 'کندکلی', 'یازتپه',
        ],
        'دهستان خانگیران': [
            'آبمال', 'اسلام‌قلعه', 'الله‌نظر', 'خانگیران', 'چاله زرد', 'چشمه شور',
            'دق بهلول', 'قطار چاه', 'کلاته الله‌نظر', 'گلزار', 'گنبدلی', 'مزیان',
            'نوبنیاد گنبدلی',
        ],
        'دهستان تجن': [
            'آصف‌آباد', 'جهند پایین', 'دولت‌آباد', 'سنگر', 'شیرتپه', 'صمدآباد',
            'قاسم‌آباد', 'قلعه قصاب', 'قوش سربوزی', 'قوش عظیم', 'کچولی',
            'کلاته مره‌ای', 'نوروزآباد',
        ],
    },
    'بخش مرزداران': {
        'دهستان گل‌بی‌بی': [
            'آبدراز', 'ارتینج', 'امیرآباد', 'بزنگان', 'بید سوخته', 'جهانگیر',
            'چنار سوخته', 'درخت بید علیا', 'درخت بید سفلی', 'زلوغال', 'قرقره',
            'کاریزک', 'کلاته عوض', 'گرماب', 'یکه بید',
        ],
        'دهستان مرزداران': [
            'باغک', 'بغ‌بغو', 'پده‌ها', 'پل گزی', 'چکودر', 'دربند علیا',
            'دربند سفلی', 'رحمت‌آباد', 'شورلق', 'قره‌قیطان',
        ],
        'دهستان پل خاتون': [
            'آق‌دربند', 'پدلی', 'پس‌کمر', 'پل خاتون', 'حاجی مدد', 'خداداد',
            'درازاب', 'شکرالله', 'شلغمی علیا', 'شلغمی سفلی', 'شلغمی وسطی',
            'شوراب سفلی', 'شوراب علیا', 'شوراب وسطی', 'شوریچه سفلی', 'شوریچه علیا',
            'صدرآباد', 'قره سنگی', 'کلاته صاحبداد', 'کلاته کیانی',
        ],
    },
}
# شهرهای مرکز بخش (این‌ها هم به‌عنوان مبدأ آگهی قابل انتخاب هستند)
CITIES = ['سرخس', 'مزداوند']

def _flatten_villages():
    out = list(CITIES)
    for bakhsh in VILLAGE_STRUCTURE.values():
        for dehestan_list in bakhsh.values():
            out += dehestan_list
    return sorted(set(out))

VILLAGES = _flatten_villages()

def village_dehestan(name):
    """دهستان یک روستا را برمی‌گرداند (برای نمایش در آگهی)"""
    for bakhsh_name, bakhsh in VILLAGE_STRUCTURE.items():
        for dehestan_name, vills in bakhsh.items():
            if name in vills:
                return dehestan_name
    if name in CITIES:
        return 'مرکز شهرستان'
    return ''

app.jinja_env.globals['village_dehestan'] = village_dehestan
app.jinja_env.globals['village_structure'] = VILLAGE_STRUCTURE
app.jinja_env.globals['cities'] = CITIES
app.jinja_env.globals['village_dehestan_map'] = {v: village_dehestan(v) for v in VILLAGES}

OWNER_PASS = os.environ.get('OWNER_PASSWORD', 'Yasinisfj123' if not IS_PRODUCTION else '')
if not OWNER_PASS and IS_PRODUCTION:
    print("\u26a0\ufe0f  هشدار: OWNER_PASSWORD در .env تنظیم نشده!")
ADMIN_PASS = os.environ.get('ADMIN_PASSWORD', 'Yasinisfj' if not IS_PRODUCTION else '')
if not ADMIN_PASS and IS_PRODUCTION:
    print("\u26a0\ufe0f  هشدار: ADMIN_PASSWORD در .env تنظیم نشده!")
ADMIN_SYSTEM_PHONE = os.environ.get('ADMIN_SYSTEM_PHONE', '00000000000')
MAX_IP_ACCOUNTS = 3

os.makedirs(UPLOAD, exist_ok=True)
os.makedirs(CHAT_UPLOAD, exist_ok=True)

# ====== DATABASE ======
def get_db():
    if 'db' not in g:
        g.db = sqlite3.connect(DB)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA journal_mode=WAL")
        g.db.execute("PRAGMA foreign_keys=ON")
    return g.db

@app.teardown_appcontext
def close_db(exc):
    db = g.pop('db', None)
    if db: db.close()

def _chat_context_key(ad_id=None, need_id=None):
    """NULL-safe, explicit identity for every conversation context."""
    if ad_id is not None and need_id is not None:
        raise ValueError('یک گفتگو نمی‌تواند هم‌زمان مربوط به آگهی و درخواست باشد')
    if ad_id is not None:
        return f'ad:{int(ad_id)}'
    if need_id is not None:
        return f'need:{int(need_id)}'
    return 'direct'

def _pair(a,b):
    return (a,b) if a < b else (b,a)

def _migrate_chat_architecture(db):
    """Safely migrate old SQLite chat schemas to context-based conversations.

    context_key is the canonical unique identity. need_id is stored explicitly for
    request conversations so UI/reporting can reliably resolve the request.
    """
    db.execute("PRAGMA foreign_keys=OFF")
    exists = db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='chats'").fetchone()
    msg_cols = {r['name'] for r in db.execute("PRAGMA table_info(messages)").fetchall()}
    chat_cols = {r['name'] for r in db.execute("PRAGMA table_info(chats)").fetchall()} if exists else set()

    if exists and 'context_key' in chat_cols:
        if 'need_id' not in chat_cols:
            db.execute("ALTER TABLE chats ADD COLUMN need_id INTEGER")
            # Future-proof any database that already has need:<id> context keys.
            rows = db.execute("SELECT id,context_key FROM chats WHERE context_key LIKE 'need:%'").fetchall()
            for row in rows:
                try:
                    nid = int(str(row['context_key']).split(':', 1)[1])
                except (ValueError, IndexError):
                    continue
                db.execute("UPDATE chats SET need_id=? WHERE id=?", (nid, row['id']))
        if 'chat_id' not in msg_cols:
            db.execute("ALTER TABLE messages ADD COLUMN chat_id INTEGER")
        db.execute("CREATE UNIQUE INDEX IF NOT EXISTS uq_chats_identity ON chats(user1_id,user2_id,context_key)")
        db.execute("CREATE INDEX IF NOT EXISTS idx_chats_need ON chats(need_id)")
        db.execute("CREATE INDEX IF NOT EXISTS idx_messages_chat_created ON messages(chat_id,created_at,id)")
        db.execute("CREATE INDEX IF NOT EXISTS idx_messages_receiver_unread ON messages(receiver_id,is_read,chat_id)")
        missing = db.execute("SELECT id,sender_id,receiver_id,ad_id FROM messages WHERE chat_id IS NULL").fetchall()
        for m in missing:
            u1,u2 = _pair(m['sender_id'],m['receiver_id'])
            ctx = _chat_context_key(m['ad_id'])
            c = db.execute("SELECT id FROM chats WHERE user1_id=? AND user2_id=? AND context_key=?", (u1,u2,ctx)).fetchone()
            if c is None:
                cur = db.execute("INSERT INTO chats(user1_id,user2_id,ad_id,need_id,context_key) VALUES(?,?,?,?,?)", (u1,u2,m['ad_id'],None,ctx))
                cid = cur.lastrowid
            else:
                cid = c['id']
            db.execute("UPDATE messages SET chat_id=? WHERE id=?", (cid,m['id']))
        db.execute("PRAGMA foreign_keys=ON")
        return

    db.execute("DROP TABLE IF EXISTS chats_new_migrate")
    db.execute("""CREATE TABLE chats_new_migrate (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user1_id INTEGER NOT NULL,user2_id INTEGER NOT NULL,
      ad_id INTEGER,need_id INTEGER,
      context_key TEXT NOT NULL,
      last_message TEXT DEFAULT '',
      last_message_at TEXT DEFAULT (datetime('now','localtime')),
      CHECK(user1_id < user2_id),
      CHECK(NOT (ad_id IS NOT NULL AND need_id IS NOT NULL)),
      UNIQUE(user1_id,user2_id,context_key)
    )""")
    candidates = {}
    if exists:
        for c in db.execute("SELECT * FROM chats"):
            u1,u2 = _pair(c['user1_id'],c['user2_id'])
            ctx = _chat_context_key(c['ad_id'])
            candidates[(u1,u2,ctx)] = (c['ad_id'],None,c['last_message'] or '',c['last_message_at'] or '')
    for m in db.execute("SELECT sender_id,receiver_id,ad_id,content,msg_type,created_at FROM messages"):
        u1,u2 = _pair(m['sender_id'],m['receiver_id'])
        ctx = _chat_context_key(m['ad_id'])
        key=(u1,u2,ctx)
        label=m['content'] if m['msg_type']=='text' else '[تصویر]'
        old=candidates.get(key)
        if old is None or str(m['created_at'] or '') >= str(old[3] or ''):
            candidates[key]=(m['ad_id'],None,label,m['created_at'] or '')
    idmap={}
    for (u1,u2,ctx),(ad,nid,last,ts) in candidates.items():
        cur=db.execute("INSERT INTO chats_new_migrate(user1_id,user2_id,ad_id,need_id,context_key,last_message,last_message_at) VALUES(?,?,?,?,?,?,?)",
            (u1,u2,ad,nid,ctx,last,ts or datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
        idmap[(u1,u2,ctx)]=cur.lastrowid
    if 'chat_id' not in msg_cols:
        db.execute("ALTER TABLE messages ADD COLUMN chat_id INTEGER")
    for m in db.execute("SELECT id,sender_id,receiver_id,ad_id FROM messages"):
        u1,u2=_pair(m['sender_id'],m['receiver_id'])
        cid=idmap.get((u1,u2,_chat_context_key(m['ad_id'])))
        if cid:
            db.execute("UPDATE messages SET chat_id=? WHERE id=?",(cid,m['id']))
    if exists:
        db.execute("DROP TABLE chats")
    db.execute("ALTER TABLE chats_new_migrate RENAME TO chats")
    db.execute("CREATE INDEX IF NOT EXISTS idx_chats_need ON chats(need_id)")
    db.execute("CREATE INDEX IF NOT EXISTS idx_messages_chat_created ON messages(chat_id,created_at,id)")
    db.execute("CREATE INDEX IF NOT EXISTS idx_messages_receiver_unread ON messages(receiver_id,is_read,chat_id)")
    db.execute("PRAGMA foreign_keys=ON")

def init_db():
    db = sqlite3.connect(DB)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys=ON")
    db.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        phone TEXT UNIQUE NOT NULL,
        first_name TEXT NOT NULL,
        last_name TEXT DEFAULT '',
        password TEXT NOT NULL,
        bio TEXT DEFAULT '',
        created_at TEXT DEFAULT (datetime('now','localtime')),
        is_banned INTEGER DEFAULT 0,
        role TEXT DEFAULT 'user',
        is_verified INTEGER DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS ads (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        category TEXT NOT NULL,
        subcategory TEXT DEFAULT '',
        price INTEGER DEFAULT 0,
        price_type TEXT DEFAULT 'fixed',
        description TEXT DEFAULT '',
        village TEXT DEFAULT '',
        village_detail TEXT DEFAULT '',
        lat REAL DEFAULT 0,
        lng REAL DEFAULT 0,
        loc_accuracy INTEGER DEFAULT 0,
        is_active INTEGER DEFAULT 1,
        is_featured INTEGER DEFAULT 0,
        views INTEGER DEFAULT 0,
        is_sold INTEGER DEFAULT 0,
        is_negotiable INTEGER DEFAULT 0,
        condition TEXT DEFAULT 'used',
        phone_visible INTEGER DEFAULT 1,
        created_at TEXT DEFAULT (datetime('now','localtime')),
        updated_at TEXT DEFAULT (datetime('now','localtime')),
        FOREIGN KEY (user_id) REFERENCES users(id)
    );
    CREATE TABLE IF NOT EXISTS ad_images (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ad_id INTEGER NOT NULL,
        filename TEXT NOT NULL,
        FOREIGN KEY (ad_id) REFERENCES ads(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS favorites (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        ad_id INTEGER NOT NULL,
        created_at TEXT DEFAULT (datetime('now','localtime')),
        UNIQUE(user_id, ad_id),
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (ad_id) REFERENCES ads(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        chat_id INTEGER,
        sender_id INTEGER NOT NULL,
        receiver_id INTEGER NOT NULL,
        ad_id INTEGER,
        content TEXT NOT NULL,
        msg_type TEXT DEFAULT 'text',
        is_read INTEGER DEFAULT 0,
        created_at TEXT DEFAULT (datetime('now','localtime')),
        FOREIGN KEY (sender_id) REFERENCES users(id),
        FOREIGN KEY (receiver_id) REFERENCES users(id)
    );
    CREATE TABLE IF NOT EXISTS chats (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user1_id INTEGER NOT NULL,
        user2_id INTEGER NOT NULL,
        ad_id INTEGER,
        need_id INTEGER,
        context_key TEXT NOT NULL DEFAULT 'direct',
        last_message TEXT DEFAULT '',
        last_message_at TEXT DEFAULT (datetime('now','localtime')),
        CHECK(user1_id < user2_id),
        CHECK(NOT (ad_id IS NOT NULL AND need_id IS NOT NULL)),
        UNIQUE(user1_id, user2_id, context_key)
    );
    CREATE TABLE IF NOT EXISTS reports (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        reporter_id INTEGER,
        ad_id INTEGER NOT NULL,
        reason TEXT NOT NULL,
        description TEXT DEFAULT '',
        status TEXT DEFAULT 'pending',
        created_at TEXT DEFAULT (datetime('now','localtime')),
        FOREIGN KEY (reporter_id) REFERENCES users(id),
        FOREIGN KEY (ad_id) REFERENCES ads(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS ip_accounts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ip_address TEXT NOT NULL,
        phone TEXT NOT NULL,
        created_at TEXT DEFAULT (datetime('now','localtime'))
    );
    CREATE TABLE IF NOT EXISTS support_messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        message TEXT NOT NULL,
        reply TEXT DEFAULT '',
        is_read INTEGER DEFAULT 0,
        created_at TEXT DEFAULT (datetime('now','localtime')),
        replied_at TEXT DEFAULT '',
        FOREIGN KEY (user_id) REFERENCES users(id)
    );
    CREATE TABLE IF NOT EXISTS needs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        description TEXT DEFAULT '',
        category TEXT DEFAULT '',
        max_price INTEGER DEFAULT 0,
        condition TEXT DEFAULT '',
        village TEXT DEFAULT '',
        quantity INTEGER DEFAULT 1,
        status TEXT DEFAULT 'active',
        view_count INTEGER DEFAULT 0,
        created_at TEXT DEFAULT (datetime('now','localtime')),
        expires_at TEXT NOT NULL,
        FOREIGN KEY (user_id) REFERENCES users(id)
    );
    CREATE TABLE IF NOT EXISTS need_reports (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        need_id INTEGER NOT NULL,
        reporter_id INTEGER,
        reason TEXT NOT NULL,
        status TEXT DEFAULT 'pending',
        created_at TEXT DEFAULT (datetime('now','localtime')),
        FOREIGN KEY (need_id) REFERENCES needs(id) ON DELETE CASCADE,
        FOREIGN KEY (reporter_id) REFERENCES users(id)
    );
    CREATE TABLE IF NOT EXISTS assistant_usage (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        usage_date TEXT NOT NULL,
        count INTEGER DEFAULT 0,
        UNIQUE(user_id, usage_date),
        FOREIGN KEY (user_id) REFERENCES users(id)
    );
    CREATE TABLE IF NOT EXISTS synonyms (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        canonical TEXT NOT NULL,
        variant TEXT NOT NULL UNIQUE
    );
    CREATE TABLE IF NOT EXISTS app_settings (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS notifications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        kind TEXT NOT NULL DEFAULT 'info',
        title TEXT NOT NULL,
        body TEXT DEFAULT '',
        link TEXT DEFAULT '',
        is_read INTEGER DEFAULT 0,
        created_at TEXT DEFAULT (datetime('now','localtime')),
        FOREIGN KEY (user_id) REFERENCES users(id)
    );
    CREATE INDEX IF NOT EXISTS idx_notifications_user_read ON notifications(user_id,is_read,created_at);
    CREATE INDEX IF NOT EXISTS idx_ads_category ON ads(category);
    CREATE INDEX IF NOT EXISTS idx_ads_village ON ads(village);
    CREATE INDEX IF NOT EXISTS idx_ads_active ON ads(is_active);
    CREATE INDEX IF NOT EXISTS idx_needs_status ON needs(status);
    CREATE INDEX IF NOT EXISTS idx_needs_expires ON needs(expires_at);
    CREATE INDEX IF NOT EXISTS idx_needs_user ON needs(user_id);
    CREATE INDEX IF NOT EXISTS idx_assistant_usage_lookup ON assistant_usage(user_id, usage_date);
    """)
    # مهاجرت‌های سبک برای دیتابیس‌های قدیمی‌تر (اگر ستون از قبل وجود داشت، خطا نادیده گرفته می‌شود)
    for stmt in [
        "ALTER TABLE ads ADD COLUMN loc_accuracy INTEGER DEFAULT 0",
        "ALTER TABLE users ADD COLUMN village TEXT DEFAULT ''",
        "ALTER TABLE users ADD COLUMN role TEXT DEFAULT 'user'",
        "ALTER TABLE users ADD COLUMN is_verified INTEGER DEFAULT 0",
    ]:
        try:
            db.execute(stmt)
        except sqlite3.OperationalError:
            pass
    # قبل از اولین مهاجرت ساختار قدیمی، یک بکاپ سازگار SQLite می‌گیریم.
    legacy_cols={r['name'] for r in db.execute("PRAGMA table_info(chats)").fetchall()}
    # بکاپ جداگانه قبل از هر مرحله مهاجرت ساختار گفتگو.
    if 'context_key' not in legacy_cols:
        backup_path=DB + '.pre_chat_migration.bak'
    elif 'need_id' not in legacy_cols:
        backup_path=DB + '.pre_need_chat_migration.bak'
    else:
        backup_path=None
    if backup_path and not os.path.exists(backup_path):
        backup_db=sqlite3.connect(backup_path)
        try:
            db.backup(backup_db)
        finally:
            backup_db.close()
    _migrate_chat_architecture(db)
    # حساب سیستمی ادمین برای پاسخگویی داخل چت؛ در production رمز فقط از محیط خوانده می‌شود.
    if ADMIN_PASS:
        admin_row=db.execute("SELECT id FROM users WHERE phone=?",(ADMIN_SYSTEM_PHONE,)).fetchone()
        if not admin_row:
            db.execute("INSERT INTO users(phone,first_name,last_name,password,bio,role,is_verified) VALUES(?,?,?,?,?,?,?)",
                       (ADMIN_SYSTEM_PHONE,'پشتیبانی','روستایار',hash_pw(ADMIN_PASS),'ادمین','admin',1))
        else:
            db.execute("UPDATE users SET role='admin',is_verified=1,bio=CASE WHEN bio='' THEN 'ادمین' ELSE bio END WHERE id=?",(admin_row['id'],))
    db.commit()
    db.close()

# ====== تنظیمات دستیار هوشمند (قابل ویرایش توسط مالک) ======
DEFAULT_SETTINGS = {
    'daily_search_limit': '3',
    'need_expire_hours': '7',
    'max_active_needs': '5',
    'max_needs_per_hour': '3',
}

def get_setting(key):
    row = get_db().execute("SELECT value FROM app_settings WHERE key=?", (key,)).fetchone()
    return row['value'] if row else DEFAULT_SETTINGS.get(key, '')

def get_setting_int(key):
    try:
        return int(get_setting(key))
    except (TypeError, ValueError):
        return int(DEFAULT_SETTINGS.get(key, 0))

def set_setting(key, value):
    db = get_db()
    db.execute("""INSERT INTO app_settings (key,value) VALUES (?,?)
        ON CONFLICT(key) DO UPDATE SET value=excluded.value""", (key, str(value)))
    db.commit()

# ====== سهمیه روزانه جستجوی هوشمند (سرور-محور، غیرقابل دستکاری از کلاینت) ======
def get_quota_usage(uid):
    db = get_db()
    today = db.execute("SELECT date('now','localtime') as d").fetchone()['d']
    row = db.execute("SELECT count FROM assistant_usage WHERE user_id=? AND usage_date=?", (uid, today)).fetchone()
    return row['count'] if row else 0

def increment_quota_usage(uid):
    db = get_db()
    today = db.execute("SELECT date('now','localtime') as d").fetchone()['d']
    db.execute("""INSERT INTO assistant_usage (user_id,usage_date,count) VALUES (?,?,1)
        ON CONFLICT(user_id,usage_date) DO UPDATE SET count=count+1""", (uid, today))
    db.commit()

def match_ad_to_active_needs(ad_id, threshold=45):
    """پس از ثبت آگهی جدید، تعداد درخواست‌های فعال «من نیاز دارم» (متعلق به کاربران دیگر) که با آن مطابقت دارند را برمی‌گرداند.
    فقط برای اطلاع‌رسانی سبک استفاده می‌شود؛ هیچ پردازش سنگین یا سرویس خارجی درگیر نیست."""
    db = get_db()
    ad = db.execute("SELECT * FROM ads WHERE id=?", (ad_id,)).fetchone()
    if not ad:
        return 0
    needs = db.execute("""SELECT * FROM needs WHERE status='active' AND user_id!=?
        AND expires_at>datetime('now','localtime') AND (category='' OR category=?)""",
        (ad['user_id'], ad['category'])).fetchall()
    cnt = 0
    for n in needs:
        s = AST.score_ad_against_need(ad, n['title'], n['description'], n['category'], n['condition'], n['village'], n['max_price'])
        if s >= threshold:
            cnt += 1
    return cnt

# ====== HELPERS ======
def is_new_ip():
    ip = get_ip()
    db = get_db()
    return db.execute("SELECT id FROM ip_accounts WHERE ip_address=?", (ip,)).fetchone() is None

def get_ip():
    xff = request.headers.get('X-Forwarded-For')
    return xff.split(',')[0].strip() if xff else (request.remote_addr or '0.0.0.0')

def hash_pw(pw):
    """هش امن رمز عبور با روش استاندارد Werkzeug (scrypt/pbkdf2 با ضریب کار بالا)"""
    return generate_password_hash(pw)

def check_pw(stored, pw):
    """پشتیبانی از هر دو قالب: هش قدیمی (salt:sha256) برای حساب‌های قدیمی، و هش جدید Werkzeug"""
    if not stored:
        return False
    if ':' in stored and not stored.startswith(('scrypt:', 'pbkdf2:')):
        # قالب قدیمی (نسخه‌های قبلی روستایار)
        s, h = stored.split(':', 1)
        return hashlib.sha256((s + pw).encode()).hexdigest() == h
    try:
        return check_password_hash(stored, pw)
    except (ValueError, TypeError):
        return False

def gen_code():
    return str(secrets.randbelow(90000) + 10000)

def upgrade_pw_hash_if_needed(db, user_id, stored, pw):
    """اگر رمز کاربر هنوز با روش قدیمی ذخیره شده، بعد از ورود موفق آن را به روش امن جدید ارتقا می‌دهد"""
    if ':' in stored and not stored.startswith(('scrypt:', 'pbkdf2:')):
        db.execute("UPDATE users SET password=? WHERE id=?", (hash_pw(pw), user_id))
        db.commit()

ALLOWED_IMG_FORMATS = {'JPEG', 'PNG', 'WEBP'}
MAX_IMG_DIMENSION = 1600  # حداکثر طول/عرض تصویر بعد از فشرده‌سازی (پیکسل)

def _validate_and_process_image(file, max_dim=MAX_IMG_DIMENSION, quality=82):
    """تصویر را واقعاً باز می‌کند (نه فقط پسوند را چک می‌کند)، فرمت واقعی را تأیید می‌کند،
    اندازه را محدود و متادیتای EXIF را حذف می‌کند. در صورت نامعتبر بودن None برمی‌گرداند."""
    try:
        from PIL import Image, ImageOps
        file.stream.seek(0)
        img = Image.open(file.stream)
        img.verify()  # بررسی سلامت فایل تصویر (جلوگیری از فایل‌های آلوده/جعلی)
        file.stream.seek(0)
        img = Image.open(file.stream)
        if img.format not in ALLOWED_IMG_FORMATS:
            return None
        img = ImageOps.exif_transpose(img)  # چرخش صحیح بر اساس EXIF قبل از حذف آن
        if img.mode not in ('RGB', 'RGBA'):
            img = img.convert('RGB')
        w, h = img.size
        if max(w, h) > max_dim:
            ratio = max_dim / max(w, h)
            img = img.resize((int(w * ratio), int(h * ratio)), Image.LANCZOS)
        return img
    except Exception:
        return None

def save_img(file, folder=None):
    if folder is None: folder = UPLOAD
    img = _validate_and_process_image(file)
    if img is None:
        return None
    fn = secrets.token_hex(8) + '.jpg'
    if img.mode == 'RGBA':
        from PIL import Image as _PILImage
        bg = _PILImage.new('RGB', img.size, (255, 255, 255))
        bg.paste(img, mask=img.split()[3])
        img = bg
    img.save(os.path.join(folder, fn), 'JPEG', quality=82, optimize=True)
    return fn

def save_chat(file):
    # چت روستایار فقط عکس می‌پذیرد (بدون ویدیو)
    img = _validate_and_process_image(file, max_dim=1280, quality=78)
    if img is None:
        return None, None
    fn = secrets.token_hex(8) + '.jpg'
    if img.mode == 'RGBA':
        from PIL import Image as _PILImage
        bg = _PILImage.new('RGB', img.size, (255, 255, 255))
        bg.paste(img, mask=img.split()[3])
        img = bg
    img.save(os.path.join(CHAT_UPLOAD, fn), 'JPEG', quality=78, optimize=True)
    return fn, 'image'

def validate_chat_target(db, sender_id, receiver_id, ad_id=None, need_id=None):
    """Validate a chat target and bind contextual chats to the real owner."""
    if ad_id is not None and need_id is not None:
        return False, 'زمینه گفتگو نامعتبر است'
    if not receiver_id:
        return False, 'گیرنده نامعتبر است'
    if receiver_id == sender_id:
        return False, 'نمی‌توانید به خودتان پیام دهید'
    receiver = db.execute("SELECT id,is_banned FROM users WHERE id=?", (receiver_id,)).fetchone()
    if not receiver:
        return False, 'کاربر گیرنده یافت نشد'
    if receiver['is_banned']:
        return False, 'این کاربر مسدود شده است'
    if ad_id is not None:
        ad = db.execute("SELECT id,user_id FROM ads WHERE id=?", (ad_id,)).fetchone()
        if not ad:
            return False, 'آگهی مورد نظر یافت نشد'
        if ad['user_id'] != receiver_id:
            return False, 'گیرنده مالک این آگهی نیست'
    if need_id is not None:
        need = db.execute("SELECT id,user_id,status FROM needs WHERE id=?", (need_id,)).fetchone()
        if not need:
            return False, 'درخواست مورد نظر یافت نشد'
        if need['user_id'] != receiver_id:
            return False, 'گیرنده مالک این درخواست نیست'
        if need['status'] != 'active':
            return False, 'این درخواست دیگر فعال نیست'
    return True, None

def get_or_create_chat(db,user_a_id,user_b_id,ad_id=None,need_id=None):
    u1,u2 = _pair(user_a_id,user_b_id)
    ctx = _chat_context_key(ad_id,need_id)
    chat = db.execute("SELECT * FROM chats WHERE user1_id=? AND user2_id=? AND context_key=?", (u1,u2,ctx)).fetchone()
    if chat:
        return chat
    try:
        cur=db.execute("INSERT INTO chats(user1_id,user2_id,ad_id,need_id,context_key) VALUES(?,?,?,?,?)", (u1,u2,ad_id,need_id,ctx))
        db.commit()
        return db.execute("SELECT * FROM chats WHERE id=?",(cur.lastrowid,)).fetchone()
    except sqlite3.IntegrityError:
        db.rollback()
        return db.execute("SELECT * FROM chats WHERE user1_id=? AND user2_id=? AND context_key=?",(u1,u2,ctx)).fetchone()

def _chat_other_id(chat,uid):
    return chat['user2_id'] if chat['user1_id']==uid else chat['user1_id']


# ===== Persian number / price formatting: single canonical strategy =====
_FA_DIGITS = '۰۱۲۳۴۵۶۷۸۹'
_AR_DIGITS = '٠١٢٣٤٥٦٧٨٩'
_EN_DIGITS = '0123456789'
_TO_EN_DIGITS = str.maketrans(_FA_DIGITS + _AR_DIGITS, _EN_DIGITS * 2)
_TO_FA_DIGITS = str.maketrans(_EN_DIGITS, _FA_DIGITS)


def normalize_number(value):
    """Return a finite numeric value or None.

    Accepts English, Persian and Arabic digits, commas and Persian/Arabic
    thousands separators. This is deliberately the only parser used for
    displayed numeric values so already-formatted values are not double-formatted.
    """
    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        try:
            if math.isfinite(float(value)):
                return value
        except (TypeError, ValueError):
            return None
        return None
    text = str(value).strip()
    if not text or text.lower() in {'undefined', 'null', 'none', 'nan'}:
        return None
    text = text.translate(_TO_EN_DIGITS)
    text = (text.replace('٬', '').replace('،', '').replace(',', '')
                .replace(' ', '').replace('‌', ''))
    # Only plain decimal numbers are accepted; prevents accidental text output.
    if not re.fullmatch(r'[+-]?(?:\d+(?:\.\d+)?|\.\d+)', text):
        return None
    try:
        number = float(text) if '.' in text else int(text)
        return number if math.isfinite(float(number)) else None
    except (TypeError, ValueError):
        return None


def to_fa_digits(value):
    """Convert only digits to Persian, leaving non-digits untouched."""
    if value is None:
        return ''
    return str(value).translate(_TO_EN_DIGITS).translate(_TO_FA_DIGITS)


def fmt_num(value, fallback='ثبت نشده'):
    """Safely format a number using Persian digits and Persian U+066C separator."""
    number = normalize_number(value)
    if number is None:
        return fallback
    if isinstance(number, float) and not number.is_integer():
        text = f'{number:,.12f}'.rstrip('0').rstrip('.')
    else:
        text = f'{int(number):,}'
    return to_fa_digits(text.replace(',', '٬'))


def fmt_price(value, missing='توافقی'):
    """Safe marketplace price formatter. Zero/invalid means negotiable by default."""
    number = normalize_number(value)
    if number is None or number <= 0:
        return missing
    return fmt_num(number, fallback=missing) + ' تومان'

app.jinja_env.globals['fmt_num'] = fmt_num
app.jinja_env.globals['fmt_price'] = fmt_price
app.jinja_env.globals['fa_digits'] = to_fa_digits

def time_ago(created_at):
    """فاصله زمانی نسبی به فارسی (مثلاً «۲ ساعت پیش»)"""
    if not created_at:
        return ''
    try:
        dt = datetime.strptime(str(created_at)[:19], '%Y-%m-%d %H:%M:%S')
    except ValueError:
        return to_fa_digits(created_at)
    diff = (datetime.now() - dt).total_seconds()
    if diff < 60:
        return 'همین الان'
    if diff < 3600:
        return f"{to_fa_digits(int(diff//60))} دقیقه پیش"
    if diff < 86400:
        return f"{to_fa_digits(int(diff//3600))} ساعت پیش"
    if diff < 86400*30:
        return f"{to_fa_digits(int(diff//86400))} روز پیش"
    if diff < 86400*365:
        return f"{to_fa_digits(int(diff//(86400*30)))} ماه پیش"
    return f"{to_fa_digits(int(diff//(86400*365)))} سال پیش"

app.jinja_env.globals['time_ago'] = time_ago

# ====== محدودسازی نرخ درخواست (Rate Limiting) ======
# پیاده‌سازی ساده در حافظه - برای استقرار چندپردازشی/چندسروری از Redis استفاده کنید
_rate_buckets = {}

def rate_limit(key_fn, max_calls, window_seconds, message='درخواست‌های شما زیاد است. کمی صبر کنید.', json_resp=False):
    """دکوریتور محدودسازی نرخ درخواست بر اساس یک کلید (مثلاً IP یا شماره موبایل).

    json_resp=True برای مسیرهای API که همیشه با fetch/AJAX صدا زده می‌شوند (مثل
    /chat/send)، تا در صورت محدود شدن هم خطا به‌صورت JSON برگردد، نه ریدایرکت HTML
    که در سمت کلاینت با response.json() قابل‌خواندن نیست."""
    def deco(f):
        @wraps(f)
        def wrapped(*args, **kwargs):
            key = f.__name__ + ':' + key_fn()
            now = time.time()
            hits = _rate_buckets.get(key, [])
            hits = [t for t in hits if now - t < window_seconds]
            if len(hits) >= max_calls:
                if request.method == 'POST' and (json_resp or request.is_json):
                    resp = jsonify({'status': 'error', 'msg': message})
                    resp.status_code = 429
                    return resp
                flash(message, 'error')
                return redirect(request.referrer or url_for('index'))
            hits.append(now)
            _rate_buckets[key] = hits
            return f(*args, **kwargs)
        return wrapped
    return deco

def _rl_ip():
    return get_ip()

def _rl_ip_phone():
    return get_ip() + ':' + request.form.get('phone', '')

# ====== محافظت CSRF ======
def _get_csrf_token():
    if 'csrf_token' not in session:
        session['csrf_token'] = secrets.token_hex(24)
    return session['csrf_token']

app.jinja_env.globals['csrf_token'] = _get_csrf_token

CSRF_EXEMPT_ENDPOINTS = set()

def csrf_exempt(f):
    """برای مسیرهایی که با API خارجی/جاوااسکریپت با هدر سفارشی کار می‌کنند و نیاز به بررسی متفاوت دارند"""
    CSRF_EXEMPT_ENDPOINTS.add(f.__name__)
    return f

@app.before_request
def _check_csrf():
    if request.method not in ('POST', 'PUT', 'DELETE', 'PATCH'):
        return
    if request.endpoint in CSRF_EXEMPT_ENDPOINTS:
        return
    if request.endpoint and request.endpoint.startswith('static'):
        return
    token = session.get('csrf_token')
    sent = request.form.get('csrf_token') or request.headers.get('X-CSRF-Token')
    if not token or not sent or not secrets.compare_digest(token, sent):
        abort(400)

@app.after_request
def _disable_auth_page_cache(response):
    if session.get('user_id') or request.path.startswith('/chat'):
        response.headers['Cache-Control']='no-store, no-cache, must-revalidate, max-age=0'
    return response

# ====== NOTIFICATIONS ======
def create_notification(db, user_id, kind, title, body='', link=''):
    if not user_id:
        return
    db.execute("INSERT INTO notifications(user_id,kind,title,body,link) VALUES(?,?,?,?,?)",
               (user_id,kind,title[:120],body[:500],link[:300]))

# ====== CONTEXT ======
@app.context_processor
def inject():
    uid = session.get('user_id')
    unread = favs = sup_unread = notif_unread = 0
    if uid:
        db = get_db()
        unread = db.execute("SELECT COUNT(*) as c FROM messages WHERE receiver_id=? AND is_read=0",(uid,)).fetchone()['c']
        favs = db.execute("SELECT COUNT(*) as c FROM favorites WHERE user_id=?",(uid,)).fetchone()['c']
        sup_unread = db.execute("SELECT COUNT(*) as c FROM support_messages WHERE user_id=? AND reply='' AND is_read=0",(uid,)).fetchone()['c']
        notif_unread = db.execute("SELECT COUNT(*) as c FROM notifications WHERE user_id=? AND is_read=0",(uid,)).fetchone()['c']
    return dict(user_id=uid, user_name=session.get('user_name',''), unread=unread, fav_count=favs, sup_unread=sup_unread, notif_unread=notif_unread)

def login_req(f):
    @wraps(f)
    def d(*a, **kw):
        if not session.get('user_id'):
            # اگر این آدرس اینترنتی قبلاً ثبت‌نام کرده، صفحه ورود؛ در غیر این صورت صفحه ثبت‌نام
            if is_new_ip():
                flash('برای این کار ابتدا باید ثبت‌نام کنید','warning')
                return redirect(url_for('register'))
            flash('لطفاً ابتدا وارد شوید','warning')
            return redirect(url_for('login'))
        db = get_db()
        u = db.execute("SELECT is_banned FROM users WHERE id=?",(session['user_id'],)).fetchone()
        if u and u['is_banned']:
            session.clear()
            flash('حساب شما مسدود شده است','error')
            return redirect(url_for('index'))
        return f(*a, **kw)
    return d

def owner_req(f):
    @wraps(f)
    def d(*a, **kw):
        if not session.get('is_owner'):
            flash('دسترسی ندارید','error')
            return redirect(url_for('owner_login'))
        return f(*a, **kw)
    return d

def admin_req(f):
    @wraps(f)
    def d(*a, **kw):
        if not session.get('is_admin'):
            flash('دسترسی ادمین ندارید','error')
            return redirect(url_for('admin_login'))
        return f(*a, **kw)
    return d

# ====== AUTH ======
OTP_TTL_SECONDS = 120       # مدت اعتبار کد تأیید
OTP_MAX_ATTEMPTS = 5        # حداکثر تلاش اشتباه قبل از باطل شدن کد
OTP_RESEND_COOLDOWN = 45    # فاصله زمانی لازم بین دو درخواست ارسال مجدد کد

def _new_otp_session(extra):
    """یک بستهٔ OTP جدید با زمان انقضا و شمارنده تلاش می‌سازد"""
    code = gen_code()
    data = dict(extra)
    data.update({'code': code, 'expires': time.time() + OTP_TTL_SECONDS, 'attempts': 0, 'sent_at': time.time()})
    return data

def _otp_check(data, submitted):
    """بررسی کد وارد شده؛ خروجی: ('ok'|'expired'|'wrong'|'locked')"""
    if data is None:
        return 'expired'
    if time.time() > data['expires']:
        return 'expired'
    if data.get('attempts', 0) >= OTP_MAX_ATTEMPTS:
        return 'locked'
    if submitted != data['code']:
        data['attempts'] = data.get('attempts', 0) + 1
        return 'wrong'
    return 'ok'

def _sms_dev_mode():
    """اگر هیچ سرویس پیامکی فعال نشده باشد، کد روی صفحه نمایش داده می‌شود (حالت آزمایشی)"""
    try:
        from sms_config import ACTIVE_PROVIDER
        return not bool(ACTIVE_PROVIDER)
    except ImportError:
        return True

@app.route('/register', methods=['GET','POST'])
@rate_limit(_rl_ip, 8, 600, 'تعداد تلاش برای ثبت‌نام از این آدرس زیاد است. کمی صبر کنید.')
def register():
    if session.get('user_id'): return redirect(url_for('index'))
    if request.method == 'POST':
        step = request.form.get('step','1')
        if step == '1':
            fn = request.form.get('first_name','').strip()
            ln = request.form.get('last_name','').strip()
            phone = request.form.get('phone','').strip()
            pw = request.form.get('password','')
            pw2 = request.form.get('confirm_password','')
            if not fn or not phone or not pw:
                flash('لطفاً فیلدهای ضروری را پر کنید','error')
                return render_template('register.html', step='1')
            if has_banned(fn) or has_banned(ln):
                flash('نام شامل کلمات نامناسب است','error')
                return render_template('register.html', step='1')
            if len(pw) < 4:
                flash('رمز عبور حداقل ۴ حرف باشد','error')
                return render_template('register.html', step='1')
            if pw != pw2:
                flash('رمزها مطابقت ندارند','error')
                return render_template('register.html', step='1')
            if not re.match(r'^09[0-9]{9}$', phone):
                flash('شماره موبایل صحیح نیست','error')
                return render_template('register.html', step='1')
            db = get_db()
            if db.execute("SELECT id FROM users WHERE phone=?",(phone,)).fetchone():
                flash('این شماره قبلاً ثبت شده','error')
                return render_template('register.html', step='1')
            ip = get_ip()
            cnt = db.execute("SELECT COUNT(*) as c FROM ip_accounts WHERE ip_address=?",(ip,)).fetchone()['c']
            if cnt >= MAX_IP_ACCOUNTS:
                flash(f'از این آدرس اینترنت حداکثر {MAX_IP_ACCOUNTS} حساب مجاز است','error')
                return render_template('register.html', step='1')
            session['reg_data'] = _new_otp_session({'fn':fn,'ln':ln,'phone':phone,'pw':pw,'ip':ip})
            send_otp_sms(phone, session['reg_data']['code'])
            dev = _sms_dev_mode()
            return render_template('register.html', step='2', phone=phone, code_hint=session['reg_data']['code'] if dev else None)
        elif step == '2':
            code_e = request.form.get('verification_code','').strip()
            rd = session.get('reg_data')
            result = _otp_check(rd, code_e)
            if result != 'ok':
                msgs = {'expired':'کد منقضی شده؛ دوباره ثبت‌نام کنید','wrong':'کد اشتباه است','locked':'تعداد تلاش بیش از حد مجاز است؛ دوباره ثبت‌نام کنید'}
                flash(msgs[result],'error')
                if result in ('expired','locked'):
                    session.pop('reg_data', None)
                    return redirect(url_for('register'))
                session['reg_data'] = rd
                return render_template('register.html', step='2', phone=rd['phone'], code_hint=rd['code'] if _sms_dev_mode() else None)
            db = get_db()
            if db.execute("SELECT id FROM users WHERE phone=?",(rd['phone'],)).fetchone():
                flash('این شماره قبلاً ثبت شده','error')
                session.pop('reg_data', None)
                return redirect(url_for('register'))
            cur = db.execute("INSERT INTO users (phone,first_name,last_name,password) VALUES (?,?,?,?)",
                       (rd['phone'], rd['fn'], rd['ln'], hash_pw(rd['pw'])))
            db.execute("INSERT INTO ip_accounts (ip_address,phone) VALUES (?,?)", (rd['ip'], rd['phone']))
            db.commit()
            uid = cur.lastrowid
            session.clear()
            # ورود خودکار بلافاصله پس از ثبت‌نام موفق - دیگر نیازی به ورود مجدد نیست
            session['user_id'] = uid
            session['user_name'] = rd['fn']
            flash(f'ثبت‌نام موفقیت‌آمیز! خوش آمدید {rd["fn"]} 🎉','success')
            return redirect(url_for('index'))
    return render_template('register.html', step='1')

@app.route('/login', methods=['GET','POST'])
@rate_limit(_rl_ip, 12, 600, 'تعداد تلاش برای ورود از این آدرس زیاد است. کمی صبر کنید.')
def login():
    if session.get('user_id'): return redirect(url_for('index'))
    if request.method == 'POST':
        step = request.form.get('step','1')
        if step == '1':
            phone = request.form.get('phone','').strip()
            pw = request.form.get('password','')
            if not phone or not pw:
                flash('شماره و رمز را وارد کنید','error')
                return render_template('login.html', step='1')
            db = get_db()
            user = db.execute("SELECT * FROM users WHERE phone=?",(phone,)).fetchone()
            if not user or not check_pw(user['password'], pw):
                flash('شماره یا رمز اشتباه است','error')
                return render_template('login.html', step='1')
            if user['is_banned']:
                flash('حساب شما مسدود شده است','error')
                return render_template('login.html', step='1')
            upgrade_pw_hash_if_needed(db, user['id'], user['password'], pw)
            session['login_data'] = _new_otp_session({'phone':phone})
            send_otp_sms(phone, session['login_data']['code'])
            dev = _sms_dev_mode()
            return render_template('login.html', step='2', phone=phone, code_hint=session['login_data']['code'] if dev else None)
        elif step == '2':
            code_e = request.form.get('verification_code','').strip()
            ld = session.get('login_data')
            result = _otp_check(ld, code_e)
            if result != 'ok':
                msgs = {'expired':'کد منقضی شده؛ دوباره وارد شوید','wrong':'کد اشتباه است','locked':'تعداد تلاش بیش از حد مجاز است؛ دوباره وارد شوید'}
                flash(msgs[result],'error')
                if result in ('expired','locked'):
                    session.pop('login_data', None)
                    return redirect(url_for('login'))
                session['login_data'] = ld
                return render_template('login.html', step='2', phone=ld['phone'], code_hint=ld['code'] if _sms_dev_mode() else None)
            db = get_db()
            user = db.execute("SELECT * FROM users WHERE phone=?",(ld['phone'],)).fetchone()
            if user:
                session.clear()
                session['user_id'] = user['id']
                session['user_name'] = user['first_name']
                flash(f'خوش آمدید {user["first_name"]}! 🌾','success')
                return redirect(url_for('index'))
    return render_template('login.html', step='1')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

# ====== بازیابی رمز عبور ======
@app.route('/forgot-password', methods=['GET','POST'])
@rate_limit(_rl_ip, 8, 600, 'تعداد تلاش زیاد است. کمی صبر کنید.')
def forgot_password():
    if session.get('user_id'): return redirect(url_for('index'))
    if request.method == 'POST':
        step = request.form.get('step','1')
        if step == '1':
            phone = request.form.get('phone','').strip()
            db = get_db()
            user = db.execute("SELECT * FROM users WHERE phone=?",(phone,)).fetchone()
            if not user:
                flash('کاربری با این شماره یافت نشد','error')
                return render_template('forgot_password.html', step='1')
            session['reset_data'] = _new_otp_session({'phone':phone})
            send_otp_sms(phone, session['reset_data']['code'])
            dev = _sms_dev_mode()
            return render_template('forgot_password.html', step='2', phone=phone, code_hint=session['reset_data']['code'] if dev else None)
        elif step == '2':
            code_e = request.form.get('verification_code','').strip()
            rd = session.get('reset_data')
            result = _otp_check(rd, code_e)
            if result != 'ok':
                msgs = {'expired':'کد منقضی شده؛ دوباره تلاش کنید','wrong':'کد اشتباه است','locked':'تعداد تلاش بیش از حد مجاز است؛ دوباره تلاش کنید'}
                flash(msgs[result],'error')
                if result in ('expired','locked'):
                    session.pop('reset_data', None)
                    return redirect(url_for('forgot_password'))
                session['reset_data'] = rd
                return render_template('forgot_password.html', step='2', phone=rd['phone'], code_hint=rd['code'] if _sms_dev_mode() else None)
            session['reset_verified'] = True
            return render_template('forgot_password.html', step='3', phone=rd['phone'])
        elif step == '3':
            rd = session.get('reset_data')
            if not rd or not session.get('reset_verified'):
                return redirect(url_for('forgot_password'))
            pw = request.form.get('password','')
            pw2 = request.form.get('confirm_password','')
            if len(pw) < 4:
                flash('رمز عبور حداقل ۴ حرف باشد','error')
                return render_template('forgot_password.html', step='3', phone=rd['phone'])
            if pw != pw2:
                flash('رمزها مطابقت ندارند','error')
                return render_template('forgot_password.html', step='3', phone=rd['phone'])
            db = get_db()
            db.execute("UPDATE users SET password=? WHERE phone=?", (hash_pw(pw), rd['phone']))
            db.commit()
            session.pop('reset_data', None)
            session.pop('reset_verified', None)
            flash('رمز عبور با موفقیت تغییر کرد ✅ حالا وارد شوید','success')
            return redirect(url_for('login'))
    return render_template('forgot_password.html', step='1')

# ====== MAIN ======
@app.route('/')
def index():
    db = get_db()
    # کاربران مهمان هم می‌توانند آگهی‌ها را ببینند (مثل دیوار)؛ فقط برای ثبت آگهی، چت و... باید عضو شوند
    q = request.args.get('q','').strip()
    cat = request.args.get('category','').strip()
    vil = request.args.get('village','').strip()
    sort = request.args.get('sort','newest')
    page = max(1, request.args.get('page',1,type=int))
    pp = 12
    where = "WHERE a.is_active=1"
    params = []
    if q:
        where += " AND (a.title LIKE ? OR a.description LIKE ?)"
        params += ['%'+q+'%','%'+q+'%']
    if cat:
        where += " AND a.category=?"
        params.append(cat)
    if vil:
        where += " AND a.village=?"
        params.append(vil)
    order = {'cheapest':"ORDER BY CASE WHEN a.price=0 THEN 1 ELSE 0 END, a.price ASC",
             'expensive':"ORDER BY a.price DESC",
             'most_viewed':"ORDER BY a.views DESC"}.get(sort, "ORDER BY a.created_at DESC")
    base = f"""SELECT a.*, (SELECT filename FROM ad_images WHERE ad_id=a.id LIMIT 1) as img,
        u.first_name as seller,
        {('(SELECT 1 FROM favorites WHERE user_id=? AND ad_id=a.id)' if session.get('user_id') else '0')} as is_fav
        FROM ads a JOIN users u ON a.user_id=u.id {where} {order}"""
    fav_params = [session['user_id']] if session.get('user_id') else []
    total = db.execute(f"SELECT COUNT(*) as c FROM ads a JOIN users u ON a.user_id=u.id {where}", params).fetchone()['c']
    pages = max(1, (total + pp - 1) // pp)
    ads = db.execute(base + " LIMIT ? OFFSET ?", fav_params + params + [pp, (page-1)*pp]).fetchall()
    stats = {
        'ads': db.execute("SELECT COUNT(*) as c FROM ads WHERE is_active=1").fetchone()['c'],
        'users': db.execute("SELECT COUNT(*) as c FROM users").fetchone()['c'],
        'villages': len(VILLAGES),
    }
    recent_needs = []
    if not q and not cat and not vil and page == 1:
        recent_needs = db.execute("""SELECT n.* FROM needs n
            WHERE n.status='active' ORDER BY n.created_at DESC LIMIT 3""").fetchall()
    return render_template('index.html', ads=ads, q=q, category=cat, village=vil, sort=sort,
        categories=list(CATEGORIES.keys()), villages=VILLAGES, count=total, page=page, pages=pages,
        stats=stats, recent_needs=recent_needs)

@app.route('/ad/<int:ad_id>')
def ad_detail(ad_id):
    db = get_db()
    ad = db.execute("SELECT a.*, u.first_name as seller, u.last_name as slast, u.phone as seller_phone, u.id as seller_uid FROM ads a JOIN users u ON a.user_id=u.id WHERE a.id=?",(ad_id,)).fetchone()
    if not ad: abort(404)
    db.execute("UPDATE ads SET views=views+1 WHERE id=?",(ad_id,))
    db.commit()
    images = db.execute("SELECT * FROM ad_images WHERE ad_id=? ORDER BY id",(ad_id,)).fetchall()
    is_fav = False
    if session.get('user_id'):
        is_fav = db.execute("SELECT id FROM favorites WHERE user_id=? AND ad_id=?",(session['user_id'],ad_id)).fetchone() is not None
    related = db.execute("SELECT a.*, (SELECT filename FROM ad_images WHERE ad_id=a.id LIMIT 1) as img FROM ads a WHERE a.is_active=1 AND a.category=? AND a.id!=? ORDER BY RANDOM() LIMIT 4",(ad['category'],ad_id)).fetchall()
    return render_template('ad_detail.html', ad=ad, images=images, is_fav=is_fav, related=related, hide_bnav=True)

@app.route('/create', methods=['GET','POST'])
@login_req
def create_ad():
    if request.method == 'POST':
        title = request.form.get('title','').strip()
        if has_banned(title):
            flash('عنوان شامل کلمات نامناسب است','error')
            return render_template('create.html', categories=list(CATEGORIES.keys()), villages=VILLAGES)
        cat = request.form.get('category','')
        sub = request.form.get('subcategory','')
        price = request.form.get('price',0,type=int)

        ptype = request.form.get('price_type','fixed')
        nego = 1 if request.form.get('is_negotiable') else 0
        cond = request.form.get('condition','used')
        vil = request.form.get('village','')
        detail = request.form.get('village_detail','')
        lat = request.form.get('lat',0,type=float)
        lng = request.form.get('lng',0,type=float)
        loc_acc = request.form.get('loc_accuracy',0,type=int)
        desc = request.form.get('description','').strip()
        phone_v = 1 if request.form.get('phone_visible') else 0
        if has_banned(desc):
            flash('توضیحات شامل کلمات نامناسب است','error')
            return render_template('create.html', categories=list(CATEGORIES.keys()), villages=VILLAGES)
        if not title or not cat:
            flash('عنوان و دسته‌بندی الزامی است','error')
            return render_template('create.html', categories=list(CATEGORIES.keys()), villages=VILLAGES)
        db = get_db()
        # جلوگیری از ثبت چندباره‌ی همان آگهی (مثلاً وقتی کاربر چند بار پشت‌سرهم روی دکمه ثبت می‌زند)
        dup = db.execute(
            "SELECT id FROM ads WHERE user_id=? AND title=? AND price=? AND category=? "
            "AND created_at >= datetime('now','localtime','-20 seconds') ORDER BY id DESC LIMIT 1",
            (session['user_id'], title, price, cat)
        ).fetchone()
        if dup:
            flash('آگهی ثبت شد! 🎉','success')
            return redirect(url_for('ad_detail', ad_id=dup['id']))
        cur = db.execute("INSERT INTO ads (user_id,title,category,subcategory,price,price_type,is_negotiable,condition,village,village_detail,lat,lng,loc_accuracy,description,phone_visible) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (session['user_id'],title,cat,sub,price,ptype,nego,cond,vil,detail,lat,lng,loc_acc,desc,phone_v))
        aid = cur.lastrowid
        for f in request.files.getlist('images'):
            if f and f.filename:
                fn = save_img(f)
                if fn: db.execute("INSERT INTO ad_images (ad_id,filename) VALUES (?,?)",(aid,fn))
        db.commit()
        # بررسی تطابق با درخواست‌های فعال «من نیاز دارم» سایر کاربران (جستجوی محلی، بدون AI خارجی)
        matched = match_ad_to_active_needs(aid)
        if matched:
            flash(f'آگهی ثبت شد! 🎉 ضمناً این آگهی با {matched} درخواست «من نیاز دارم» فعال مطابقت دارد؛ می‌تونی از بخش «من نیاز دارم» ببینی.','success')
        else:
            flash('آگهی ثبت شد! 🎉','success')
        return redirect(url_for('ad_detail', ad_id=aid))
    return render_template('create.html', categories=list(CATEGORIES.keys()), villages=VILLAGES)

@app.route('/ad/<int:ad_id>/edit', methods=['GET','POST'])
@login_req
def edit_ad(ad_id):
    db = get_db()
    ad = db.execute("SELECT * FROM ads WHERE id=? AND user_id=?",(ad_id,session['user_id'])).fetchone()
    if not ad: return redirect(url_for('my_ads'))
    images = db.execute("SELECT * FROM ad_images WHERE ad_id=? ORDER BY id",(ad_id,)).fetchall()
    if request.method == 'POST':
        title = request.form.get('title','').strip()
        desc = request.form.get('description','').strip()
        if has_banned(title) or has_banned(desc):
            flash('متن آگهی شامل کلمات نامناسب است','error')
            return render_template('edit_ad.html', ad=ad, images=images, categories=list(CATEGORIES.keys()), villages=VILLAGES)
        db.execute("""UPDATE ads SET title=?, category=?, subcategory=?, price=?, price_type=?,
            is_negotiable=?, condition=?, village=?, village_detail=?, lat=?, lng=?, loc_accuracy=?,
            description=?, phone_visible=?, is_sold=?, updated_at=datetime('now','localtime') WHERE id=?""",
            (title, request.form.get('category',''), request.form.get('subcategory',''),
             request.form.get('price',0,type=int), request.form.get('price_type','fixed'),
             1 if request.form.get('is_negotiable') else 0, request.form.get('condition','used'),
             request.form.get('village',''), request.form.get('village_detail',''),
             request.form.get('lat',0,type=float), request.form.get('lng',0,type=float),
             request.form.get('loc_accuracy',0,type=int),
             desc,
             1 if request.form.get('phone_visible') else 0,
             1 if request.form.get('is_sold') else 0, ad_id))

        # حذف عکس‌های انتخاب‌شده توسط کاربر (فقط عکس‌های متعلق به همین آگهی)
        del_ids = request.form.getlist('delete_images', type=int)
        remaining = len(images)
        if del_ids:
            for iid in del_ids:
                img = db.execute("SELECT * FROM ad_images WHERE id=? AND ad_id=?",(iid,ad_id)).fetchone()
                if img:
                    p = os.path.join(UPLOAD, img['filename'])
                    if os.path.exists(p): os.remove(p)
                    db.execute("DELETE FROM ad_images WHERE id=?",(iid,))
                    remaining -= 1

        # افزودن عکس‌های جدید بدون حذف عکس‌های قبلی که نگه داشته شدند
        new_files = [f for f in request.files.getlist('images') if f and f.filename]
        if new_files:
            room = max(0, 6 - remaining)
            if len(new_files) > room:
                flash(f'حداکثر ۶ عکس برای هر آگهی مجاز است؛ فقط {room} عکس جدید ذخیره شد.' if room else 'به حداکثر تعداد عکس (۶ عکس) رسیده‌اید؛ برای افزودن عکس جدید ابتدا یکی را حذف کنید.','error')
            for f in new_files[:room]:
                fn = save_img(f)
                if fn: db.execute("INSERT INTO ad_images (ad_id,filename) VALUES (?,?)",(ad_id,fn))

        db.commit()
        flash('بروزرسانی شد ✅','success')
        return redirect(url_for('ad_detail', ad_id=ad_id))
    return render_template('edit_ad.html', ad=ad, images=images, categories=list(CATEGORIES.keys()), villages=VILLAGES)

@app.route('/ad/<int:ad_id>/delete', methods=['POST'])
@login_req
def delete_ad(ad_id):
    db = get_db()
    ad = db.execute("SELECT id FROM ads WHERE id=? AND user_id=?",(ad_id,session['user_id'])).fetchone()
    if ad:
        db.execute("DELETE FROM ads WHERE id=?",(ad_id,))
        db.commit()
    return redirect(url_for('my_ads'))

@app.route('/my-ads')
@login_req
def my_ads():
    db = get_db()
    ads = db.execute("SELECT a.*, (SELECT filename FROM ad_images WHERE ad_id=a.id LIMIT 1) as img FROM ads a WHERE a.user_id=? ORDER BY a.created_at DESC",(session['user_id'],)).fetchall()
    return render_template('my_ads.html', ads=ads)

# ====== FAVORITES ======
@app.route('/fav/<int:ad_id>', methods=['POST'])
@login_req
def toggle_fav(ad_id):
    db = get_db()
    ex = db.execute("SELECT id FROM favorites WHERE user_id=? AND ad_id=?",(session['user_id'],ad_id)).fetchone()
    if ex:
        db.execute("DELETE FROM favorites WHERE id=?",(ex['id'],)); db.commit()
        return jsonify({'status':'removed'})
    db.execute("INSERT INTO favorites (user_id,ad_id) VALUES (?,?)",(session['user_id'],ad_id)); db.commit()
    return jsonify({'status':'added'})

@app.route('/favorites')
@login_req
def favorites():
    db = get_db()
    ads = db.execute("SELECT a.*, (SELECT filename FROM ad_images WHERE ad_id=a.id LIMIT 1) as img FROM favorites f JOIN ads a ON f.ad_id=a.id WHERE f.user_id=? ORDER BY f.created_at DESC",(session['user_id'],)).fetchall()
    return render_template('favorites.html', ads=ads)

# ====== CHAT ======
@app.route('/chat')
@login_req
def chat_list():
    db=get_db(); uid=session['user_id']
    rows=db.execute("""SELECT c.*,
      CASE WHEN c.user1_id=? THEN u2.id ELSE u1.id END oid,
      CASE WHEN c.user1_id=? THEN u2.first_name ELSE u1.first_name END oname,
      CASE WHEN c.user1_id=? THEN u2.last_name ELSE u1.last_name END olast,
      (SELECT COUNT(*) FROM messages m WHERE m.chat_id=c.id AND m.receiver_id=? AND m.is_read=0) unread_count,
      a.title ad_title, n.title need_title
      FROM chats c
      JOIN users u1 ON u1.id=c.user1_id
      JOIN users u2 ON u2.id=c.user2_id
      LEFT JOIN ads a ON a.id=c.ad_id
      LEFT JOIN needs n ON n.id=c.need_id
      WHERE c.user1_id=? OR c.user2_id=?
      ORDER BY CASE WHEN c.last_message_at IS NULL THEN 1 ELSE 0 END, datetime(c.last_message_at) DESC,c.id DESC""",(uid,uid,uid,uid,uid,uid)).fetchall()
    chats=[]
    for row in rows:
        c=dict(row)
        raw_last=(c.get('last_message') or '').strip()
        if raw_last in {'[تصویر]','[image]'}:
            c['last_preview']='📷 تصویر'
        elif raw_last:
            c['last_preview']=raw_last
        else:
            c['last_preview']='هنوز پیامی ارسال نشده است'
        c['time_ago']=time_ago(c.get('last_message_at')) if c.get('last_message_at') else ''
        c['unread_count']=int(c.get('unread_count') or 0)
        chats.append(c)
    return render_template('chat_list.html',chats=chats)

@app.route('/chat/c/<int:chat_id>')
@login_req
def chat_room_by_id(chat_id):
    db=get_db(); uid=session['user_id']
    chat=db.execute("SELECT * FROM chats WHERE id=? AND (user1_id=? OR user2_id=?)",(chat_id,uid,uid)).fetchone()
    if not chat: abort(404)
    other=db.execute("SELECT * FROM users WHERE id=?",(_chat_other_id(chat,uid),)).fetchone()
    db.execute("UPDATE messages SET is_read=1 WHERE chat_id=? AND receiver_id=? AND is_read=0",(chat_id,uid)); db.commit()
    msgs=db.execute("SELECT m.*,u.first_name sname FROM messages m JOIN users u ON u.id=m.sender_id WHERE m.chat_id=? ORDER BY datetime(m.created_at),m.id",(chat_id,)).fetchall()
    ad_info=db.execute("SELECT title FROM ads WHERE id=?",(chat['ad_id'],)).fetchone() if chat['ad_id'] is not None else None
    need_info=db.execute("SELECT title FROM needs WHERE id=?",(chat['need_id'],)).fetchone() if chat['need_id'] is not None else None
    return render_template('chat_room.html',other=other,messages=msgs,chat=chat,
        ad_info=ad_info,need_info=need_info,hide_bnav=True,body_class='chat-page',
        prefill=request.args.get('prefill','')[:300])

@app.route('/chat/<int:oid>')
@app.route('/chat/<int:oid>/<int:ad_id>')
@login_req
def chat_room(oid,ad_id=None):
    db=get_db(); ok,err=validate_chat_target(db,session['user_id'],oid,ad_id=ad_id)
    if not ok: flash(err,'error'); return redirect(url_for('chat_list'))
    chat=get_or_create_chat(db,session['user_id'],oid,ad_id=ad_id)
    return redirect(url_for('chat_room_by_id',chat_id=chat['id'],prefill=request.args.get('prefill','')))

@app.route('/needs/<int:need_id>/contact', methods=['GET','POST'])
@login_req
def contact_need_owner(need_id):
    """Open a request-scoped conversation. The receiver is always derived server-side.

    POST is the normal production path. GET remains temporarily compatible with old
    cached/mobile pages, but the request id is still fully validated and no receiver
    id supplied by the client is trusted.
    """
    db=get_db(); uid=session['user_id']
    need=db.execute("SELECT id,user_id,title,status FROM needs WHERE id=?",(need_id,)).fetchone()
    if not need:
        abort(404)
    if need['user_id'] == uid:
        flash('این درخواست متعلق به خود شماست','error')
        return redirect(url_for('my_needs'))
    ok,err=validate_chat_target(db,uid,need['user_id'],need_id=need_id)
    if not ok:
        flash(err,'error'); return redirect(url_for('needs_feed'))
    chat=get_or_create_chat(db,uid,need['user_id'],need_id=need_id)
    prefill=f"سلام، من این کالا را دارم: {need['title']}"
    return redirect(url_for('chat_room_by_id',chat_id=chat['id'],prefill=prefill))

@app.route('/chat/send',methods=['POST'])
@login_req
@rate_limit(lambda: str(session.get('user_id','')),20,60,'پیام‌های شما زیاد است. کمی صبر کنید.',json_resp=True)
def chat_send():
    db=get_db(); uid=session['user_id']; chat_id=request.form.get('chat_id',type=int)
    chat=db.execute("SELECT * FROM chats WHERE id=? AND (user1_id=? OR user2_id=?)",(chat_id,uid,uid)).fetchone() if chat_id else None
    if not chat: return jsonify({'status':'error','msg':'گفتگو یافت نشد'}),404
    rid=_chat_other_id(chat,uid); content=request.form.get('content','').strip(); f=request.files.get('file'); mt='text'
    if f and f.filename:
        fn,ftype=save_chat(f)
        if not fn: return jsonify({'status':'error','msg':'فقط ارسال عکس مجاز است'}),400
        content=fn; mt=ftype
    elif content and has_banned(content): return jsonify({'status':'error','msg':'پیام نامناسب است'}),400
    elif not content: return jsonify({'status':'error','msg':'پیام خالی'}),400
    db.execute("INSERT INTO messages(chat_id,sender_id,receiver_id,ad_id,content,msg_type) VALUES(?,?,?,?,?,?)",(chat_id,uid,rid,chat['ad_id'],content,mt))
    db.execute("UPDATE chats SET last_message=?,last_message_at=datetime('now','localtime') WHERE id=?",(content if mt=='text' else '[تصویر]',chat_id))
    sender=db.execute("SELECT first_name FROM users WHERE id=?",(uid,)).fetchone()
    preview='📷 تصویر جدید' if mt!='text' else content[:120]
    create_notification(db,rid,'chat',f"پیام جدید از {(sender['first_name'] if sender else 'کاربر')}",preview,url_for('chat_room_by_id',chat_id=chat_id))
    db.commit()
    return jsonify({'status':'ok','msg_type':mt})

@app.route('/chat/messages/<int:chat_id>')
@login_req
def chat_messages(chat_id):
    db=get_db(); uid=session['user_id']
    if not db.execute("SELECT id FROM chats WHERE id=? AND (user1_id=? OR user2_id=?)",(chat_id,uid,uid)).fetchone():
        return jsonify({'status':'error','msg':'گفتگو یافت نشد'}),404
    db.execute("UPDATE messages SET is_read=1 WHERE chat_id=? AND receiver_id=? AND is_read=0",(chat_id,uid)); db.commit()
    msgs=db.execute("SELECT m.*,u.first_name sname FROM messages m JOIN users u ON u.id=m.sender_id WHERE m.chat_id=? ORDER BY datetime(m.created_at),m.id",(chat_id,)).fetchall()
    return jsonify([{'id':m['id'],'sender_id':m['sender_id'],'sname':m['sname'],'content':m['content'],'msg_type':m['msg_type'],'created_at':m['created_at']} for m in msgs])

# ====== NOTIFICATIONS ======
@app.route('/notifications')
@login_req
def notifications():
    db=get_db(); uid=session['user_id']
    items=db.execute("SELECT * FROM notifications WHERE user_id=? ORDER BY datetime(created_at) DESC,id DESC LIMIT 100",(uid,)).fetchall()
    db.execute("UPDATE notifications SET is_read=1 WHERE user_id=?",(uid,)); db.commit()
    return render_template('notifications.html', items=items)

# ====== SUPPORT ======
@app.route('/info/<page>')
def info_page(page):
    if page not in INFO_PAGES:
        abort(404)
    return render_template('info.html', page_key=page, info=INFO_PAGES[page])

@app.route('/support', methods=['GET','POST'])
@login_req
def support():
    db = get_db()
    if request.method == 'POST':
        msg = request.form.get('message','').strip()
        if msg:
            db.execute("INSERT INTO support_messages (user_id,message) VALUES (?,?)",(session['user_id'],msg))
            db.commit()
            flash('پیام شما ارسال شد 🙏','success')
            return redirect(url_for('support'))
    msgs = db.execute("SELECT * FROM support_messages WHERE user_id=? ORDER BY created_at DESC",(session['user_id'],)).fetchall()
    return render_template('support.html', messages=msgs)

# ====== PROFILE ======
@app.route('/profile')
@login_req
def profile():
    db = get_db()
    u = db.execute("SELECT * FROM users WHERE id=?",(session['user_id'],)).fetchone()
    cnt = db.execute("SELECT COUNT(*) as c FROM ads WHERE user_id=?",(session['user_id'],)).fetchone()['c']
    total_views = db.execute("SELECT COALESCE(SUM(views),0) as c FROM ads WHERE user_id=?",(session['user_id'],)).fetchone()['c']
    return render_template('profile.html', user=u, my_ads_count=cnt, total_views=total_views)

@app.route('/profile/edit', methods=['GET','POST'])
@login_req
def edit_profile():
    db = get_db()
    u = db.execute("SELECT * FROM users WHERE id=?",(session['user_id'],)).fetchone()
    if request.method == 'POST':
        fn = request.form.get('first_name','').strip()
        ln = request.form.get('last_name','').strip()
        bio = request.form.get('bio','').strip()
        village = request.form.get('village','').strip()
        if not fn: flash('نام الزامی','error')
        elif village and village not in VILLAGES: flash('روستای انتخاب‌شده معتبر نیست','error')
        else:
            db.execute("UPDATE users SET first_name=?, last_name=?, bio=?, village=? WHERE id=?",(fn,ln,bio,village,session['user_id']))
            db.commit(); session['user_name'] = fn
            flash('بروزرسانی شد ✅','success')
            return redirect(url_for('profile'))
    return render_template('edit_profile.html', user=u)

# ====== REPORT ======
@app.route('/report/<int:ad_id>', methods=['GET','POST'])
@login_req
@rate_limit(lambda: str(session.get('user_id','')), 10, 3600, 'تعداد گزارش شما در این ساعت زیاد است.')
def report_ad(ad_id):
    db = get_db()
    ad = db.execute("SELECT title FROM ads WHERE id=?",(ad_id,)).fetchone()
    if not ad: return redirect(url_for('index'))
    if request.method == 'POST':
        reason = request.form.get('reason','')
        desc = request.form.get('description','').strip()
        if reason:
            db.execute("INSERT INTO reports (reporter_id,ad_id,reason,description) VALUES (?,?,?,?)",(session['user_id'],ad_id,reason,desc))
            db.commit(); flash('گزارش ثبت شد 🙏','success')
            return redirect(url_for('ad_detail', ad_id=ad_id))
    return render_template('report.html', ad=ad, ad_id=ad_id)

@app.route('/api/subcategories')
def api_subcategories():
    return jsonify(CATEGORIES.get(request.args.get('category',''), []))

# ====== دستیار هوشمند روستایار (محلی، بدون AI خارجی) ======
@app.route('/assistant')
@login_req
def assistant_page():
    limit = get_setting_int('daily_search_limit')
    used = get_quota_usage(session['user_id'])
    return render_template('assistant.html', hide_bnav=True, body_class='chat-page',
        quota_used=used, quota_limit=limit)

@app.route('/assistant/message', methods=['POST'])
@login_req
@rate_limit(lambda: str(session.get('user_id','')), 25, 60, 'پیام‌های شما زیاد است. کمی صبر کنید.')
def assistant_message():
    raw = (request.form.get('text') or '').strip()[:300]
    limit = get_setting_int('daily_search_limit')
    used = get_quota_usage(session['user_id'])
    uid = session['user_id']
    base = {'quota_used': used, 'quota_limit': limit}

    if has_banned(raw):
        return jsonify({**base, 'type': 'text', 'reply': AST.reply_banned()})

    norm = AST.normalize_fa(raw)
    intent = AST.classify_intent(norm, CATEGORIES, VILLAGES)

    # — پیگیری متن (Context Tracking): اگر پیام مبهم است و کاربر قبلاً جستجو کرده —
    ctx = AST.get_context(uid)

    if intent == 'need_request':
        AST.clear_context(uid)
        return jsonify({**base, 'type': 'text', 'reply': AST.generate_conversation_response(intent),
            'need_url': url_for('need_create')})

    if intent != 'search_product':
        # پیام مکالمه‌ای/نامشخص — سهمیه مصرف نمی‌شود
        reply = AST.generate_conversation_response(intent)
        # اگر unclear است و کاربر قبلاً جستجو کرده، سرنخ بده
        if intent == 'unclear' and ctx:
            ctx_cats = ctx.get('last_category') or 'کالا'
            reply += f'\n\n💡 اگر هنوز دنبال «{ctx_cats}» هستی، کافیه دقیق‌تر بنویسی.'
        elif intent == 'unclear':
            sug = AST.get_smart_suggestions(raw)
            if sug:
                reply += f'\n\n💡 {sug}'
        return jsonify({**base, 'type': 'text', 'reply': reply})

    # — جستجوی واقعی —
    db = get_db()
    syn_rows = db.execute("SELECT variant, canonical FROM synonyms").fetchall()
    syn_map = {AST.normalize_fa(r['variant']): AST.normalize_fa(r['canonical']) for r in syn_rows}
    norm_exp = AST.expand_synonyms(norm, syn_map)

    min_price, max_price = AST.extract_price(norm_exp)
    condition = AST.extract_condition(norm_exp)
    village = AST.extract_village(norm_exp, VILLAGES)
    category, _via_kw = AST.extract_category(norm_exp, CATEGORIES)
    exclude = {AST.normalize_fa(village)} if village else set()
    keywords = AST.extract_keywords(norm_exp, exclude=exclude)

    if not keywords and not category and not village and not condition and not max_price and not min_price:
        return jsonify({**base, 'type': 'text', 'reply': AST.reply_ask_what()})

    if used >= limit:
        AST.clear_context(uid)
        return jsonify({**base, 'type': 'quota_exceeded',
            'reply': AST.reply_quota_exceeded()})

    # ذخیره متن برای پیگیری
    AST.save_context(uid, intent, keywords, category)

    ads = db.execute("SELECT a.*, (SELECT filename FROM ad_images WHERE ad_id=a.id LIMIT 1) as img FROM ads a WHERE a.is_active=1").fetchall()
    scored = []
    for ad in ads:
        s = AST.score_ad(ad, keywords, category, condition, village, min_price, max_price)
        if s > 0:
            scored.append((s, ad))
    scored.sort(key=lambda x: -x[0])
    top = scored[:10]

    increment_quota_usage(session['user_id'])
    used += 1
    base['quota_used'] = used

    if not top:
        return jsonify({**base, 'type': 'no_results',
            'reply': AST.reply_no_results(),
            'need_url': url_for('need_create', title=raw[:100], category=category or '', max_price=max_price or '', condition=condition or '', village=village or '')})

    results = []
    for s, ad in top:
        label = 'بیشترین تطابق' if s >= 70 else ('تطابق خوب' if s >= 40 else 'نتیجه مرتبط')
        results.append({
            'id': ad['id'], 'title': ad['title'],
            'price': fmt_price(ad['price']),
            'village': ad['village'] or 'سرخس', 'img': ad['img'],
            'score': s, 'label': label, 'url': url_for('ad_detail', ad_id=ad['id']),
        })
    return jsonify({**base, 'type': 'search_results', 'reply': AST.reply_search_intro(to_fa_digits(len(results))), 'results': results})
# ====== «من نیاز دارم» ======
def _expire_needs(db):
    db.execute("UPDATE needs SET status='expired' WHERE status='active' AND expires_at<=datetime('now','localtime')")
    db.commit()

@app.route('/needs')
def needs_feed():
    db = get_db()
    _expire_needs(db)
    rows = db.execute("""SELECT n.*, u.first_name as uname FROM needs n JOIN users u ON n.user_id=u.id
        WHERE n.status='active' ORDER BY n.created_at DESC""").fetchall()
    return render_template('needs_feed.html', needs=rows)

@app.route('/needs/create', methods=['GET','POST'])
@login_req
def need_create():
    db = get_db()
    if request.method == 'POST':
        title = request.form.get('title','').strip()
        desc = request.form.get('description','').strip()
        category = request.form.get('category','')
        max_price = request.form.get('max_price',0,type=int)
        condition = request.form.get('condition','')
        village = request.form.get('village','')
        qty = request.form.get('quantity',1,type=int) or 1
        ctx = dict(categories=list(CATEGORIES.keys()), villages=VILLAGES, prefill_title=title,
                    prefill_category=category, prefill_village=village)
        if not title or len(title) < 3:
            flash('عنوان کالا الزامی است (حداقل ۳ حرف)','error')
            return render_template('need_form.html', **ctx)
        if has_banned(title) or has_banned(desc):
            flash('متن درخواست شامل کلمات نامناسب است','error')
            return render_template('need_form.html', **ctx)
        max_active = get_setting_int('max_active_needs')
        active_cnt = db.execute("SELECT COUNT(*) as c FROM needs WHERE user_id=? AND status='active'",(session['user_id'],)).fetchone()['c']
        if active_cnt >= max_active:
            flash(f'حداکثر {max_active} درخواست فعال مجاز است؛ ابتدا یکی را حذف کن یا منتظر انقضا بمان.','error')
            return redirect(url_for('my_needs'))
        max_per_hour = get_setting_int('max_needs_per_hour')
        hour_cnt = db.execute("SELECT COUNT(*) as c FROM needs WHERE user_id=? AND created_at>=datetime('now','localtime','-1 hour')",(session['user_id'],)).fetchone()['c']
        if hour_cnt >= max_per_hour:
            flash(f'حداکثر {max_per_hour} درخواست در هر ساعت مجاز است؛ کمی صبر کن.','error')
            return redirect(url_for('my_needs'))
        now = datetime.now()
        hours = get_setting_int('need_expire_hours')
        created = now.strftime('%Y-%m-%d %H:%M:%S')
        expires = (now + timedelta(hours=hours)).strftime('%Y-%m-%d %H:%M:%S')
        db.execute("""INSERT INTO needs (user_id,title,description,category,max_price,condition,village,quantity,created_at,expires_at)
            VALUES (?,?,?,?,?,?,?,?,?,?)""",
            (session['user_id'], title, desc, category, max_price, condition, village, qty, created, expires))
        db.commit()
        flash(f'درخواستت با موفقیت ثبت شد و تا {hours} ساعت آینده فعال است 📢','success')
        return redirect(url_for('needs_feed'))
    return render_template('need_form.html', categories=list(CATEGORIES.keys()), villages=VILLAGES,
        prefill_title=request.args.get('title',''), prefill_category=request.args.get('category',''),
        prefill_village=request.args.get('village',''), prefill_price=request.args.get('max_price',''),
        prefill_condition=request.args.get('condition',''))

@app.route('/my-needs')
@login_req
def my_needs():
    db = get_db()
    _expire_needs(db)
    active = db.execute("SELECT * FROM needs WHERE user_id=? AND status='active' ORDER BY created_at DESC",(session['user_id'],)).fetchall()
    expired = db.execute("SELECT * FROM needs WHERE user_id=? AND status!='active' ORDER BY created_at DESC LIMIT 30",(session['user_id'],)).fetchall()
    return render_template('my_needs.html', active=active, expired=expired)

@app.route('/needs/<int:need_id>/delete', methods=['POST'])
@login_req
def need_delete(need_id):
    db = get_db()
    db.execute("DELETE FROM needs WHERE id=? AND user_id=?",(need_id, session['user_id']))
    db.commit()
    flash('درخواست حذف شد','success')
    return redirect(url_for('my_needs'))

@app.route('/needs/<int:need_id>/report', methods=['POST'])
@login_req
def need_report(need_id):
    db = get_db()
    reason = request.form.get('reason','نامشخص').strip()
    n = db.execute("SELECT id FROM needs WHERE id=?",(need_id,)).fetchone()
    if n and reason:
        db.execute("INSERT INTO need_reports (need_id,reporter_id,reason) VALUES (?,?,?)",(need_id, session['user_id'], reason))
        db.commit()
        flash('گزارش ثبت شد 🙏','success')
    return redirect(url_for('needs_feed'))

# ====== ADMIN PANEL ======
@app.route('/admin/login', methods=['GET','POST'])
@rate_limit(_rl_ip,8,300,'تعداد تلاش ورود زیاد است. کمی صبر کنید.')
def admin_login():
    if session.get('is_admin'): return redirect(url_for('admin_dashboard'))
    if request.method=='POST':
        if not ADMIN_PASS:
            flash('رمز ادمین در تنظیمات سرور تعریف نشده است','error'); return render_template('admin_login.html')
        if secrets.compare_digest(request.form.get('password',''),ADMIN_PASS):
            db=get_db(); u=db.execute("SELECT * FROM users WHERE phone=?",(ADMIN_SYSTEM_PHONE,)).fetchone()
            if not u:
                flash('حساب سیستمی ادمین ساخته نشده است؛ سرور را یک‌بار راه‌اندازی مجدد کنید','error')
                return render_template('admin_login.html')
            session.clear(); session['is_admin']=True; session['user_id']=u['id']; session['user_name']=u['first_name']
            flash('خوش آمدید ادمین 🌾','success'); return redirect(url_for('admin_dashboard'))
        flash('رمز اشتباه است','error')
    return render_template('admin_login.html')

@app.route('/admin')
@admin_req
def admin_dashboard():
    db=get_db()
    stats={
      'pending_reports':db.execute("SELECT COUNT(*) c FROM reports WHERE status='pending'").fetchone()['c'],
      'support':db.execute("SELECT COUNT(*) c FROM support_messages WHERE reply=''").fetchone()['c'],
      'banned':db.execute("SELECT COUNT(*) c FROM users WHERE is_banned=1").fetchone()['c']}
    reports=db.execute("SELECT r.*,a.title ad_title,u.first_name rname FROM reports r JOIN ads a ON a.id=r.ad_id LEFT JOIN users u ON u.id=r.reporter_id WHERE r.status='pending' ORDER BY datetime(r.created_at) DESC LIMIT 30").fetchall()
    support_msgs=db.execute("SELECT s.*,u.first_name uname FROM support_messages s JOIN users u ON u.id=s.user_id WHERE s.reply='' ORDER BY datetime(s.created_at) DESC LIMIT 30").fetchall()
    return render_template('admin.html',stats=stats,reports=reports,support_msgs=support_msgs)

@app.route('/admin/users')
@admin_req
def admin_users():
    db=get_db(); users=db.execute("SELECT id,phone,first_name,last_name,bio,is_banned,role,created_at FROM users WHERE role!='admin' ORDER BY datetime(created_at) DESC").fetchall()
    return render_template('admin_users.html',users=users)

@app.route('/admin/ban/<int:uid>',methods=['POST'])
@admin_req
def admin_ban(uid):
    db=get_db(); db.execute("UPDATE users SET is_banned=1 WHERE id=? AND role!='admin'",(uid,)); db.commit(); flash('کاربر مسدود شد','success'); return redirect(url_for('admin_users'))

@app.route('/admin/unban/<int:uid>',methods=['POST'])
@admin_req
def admin_unban(uid):
    db=get_db(); db.execute("UPDATE users SET is_banned=0 WHERE id=? AND role!='admin'",(uid,)); db.commit(); flash('مسدودیت برداشته شد','success'); return redirect(url_for('admin_users'))

@app.route('/admin/reset-password',methods=['POST'])
@admin_req
def admin_reset_password():
    phone=request.form.get('phone','').strip(); new_pw=request.form.get('new_password','')
    if len(new_pw)<8:
        flash('رمز موقت حداقل ۸ کاراکتر باشد','error'); return redirect(url_for('admin_users'))
    db=get_db(); u=db.execute("SELECT id FROM users WHERE phone=? AND role!='admin'",(phone,)).fetchone()
    if not u: flash('کاربری با این شماره پیدا نشد','error')
    else:
        db.execute("UPDATE users SET password=? WHERE id=?",(hash_pw(new_pw),u['id'])); db.commit(); flash('رمز جدید با موفقیت تنظیم شد؛ رمز قبلی قابل مشاهده یا بازیابی نیست.','success')
    return redirect(url_for('admin_users'))

@app.route('/admin/report/<int:rid>/resolve',methods=['POST'])
@admin_req
def admin_resolve(rid):
    db=get_db(); action=request.form.get('action','dismiss')
    r=db.execute("SELECT ad_id FROM reports WHERE id=?",(rid,)).fetchone()
    if r and action=='delete_ad':
        db.execute("DELETE FROM ads WHERE id=?",(r['ad_id'],))
    elif r and action=='ban_user':
        a=db.execute("SELECT user_id FROM ads WHERE id=?",(r['ad_id'],)).fetchone()
        if a: db.execute("UPDATE users SET is_banned=1 WHERE id=? AND role!='admin'",(a['user_id'],))
    db.execute("UPDATE reports SET status='resolved' WHERE id=?",(rid,)); db.commit()
    flash('گزارش بررسی شد','success'); return redirect(url_for('admin_dashboard'))

@app.route('/admin/support/<int:sid>/reply',methods=['POST'])
@admin_req
def admin_reply(sid):
    db=get_db(); reply=request.form.get('reply','').strip()
    if reply:
        db.execute("UPDATE support_messages SET reply=?, replied_at=datetime('now','localtime') WHERE id=?",(reply,sid))
        target=db.execute("SELECT user_id FROM support_messages WHERE id=?",(sid,)).fetchone()
        if target: create_notification(db,target['user_id'],'support','پاسخ جدید پشتیبانی',reply,url_for('support'))
        db.commit(); flash('پاسخ ارسال شد','success')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/logout')
def admin_logout():
    session.clear(); return redirect(url_for('index'))

# ====== OWNER PANEL ======
@app.route('/modir/login', methods=['GET','POST'])
@rate_limit(_rl_ip, 8, 300, 'تعداد تلاش ورود زیاد است. چند دقیقه صبر کنید.')
def owner_login():
    if session.get('is_owner'): return redirect(url_for('owner_dashboard'))
    if request.method == 'POST':
        if secrets.compare_digest(request.form.get('password',''), OWNER_PASS):
            session['is_owner'] = True; return redirect(url_for('owner_dashboard'))
        flash('رمز اشتباه','error')
    return render_template('owner_login.html')

@app.route('/modir')
@owner_req
def owner_dashboard():
    db = get_db()
    stats = {
        'total_ads': db.execute("SELECT COUNT(*) as c FROM ads").fetchone()['c'],
        'active_ads': db.execute("SELECT COUNT(*) as c FROM ads WHERE is_active=1").fetchone()['c'],
        'total_users': db.execute("SELECT COUNT(*) as c FROM users").fetchone()['c'],
        'pending_reports': db.execute("SELECT COUNT(*) as c FROM reports WHERE status='pending'").fetchone()['c'],
        'banned': db.execute("SELECT COUNT(*) as c FROM users WHERE is_banned=1").fetchone()['c'],
        'total_views': db.execute("SELECT COALESCE(SUM(views),0) as c FROM ads").fetchone()['c'],
        'today_ads': db.execute("SELECT COUNT(*) as c FROM ads WHERE date(created_at)=date('now','localtime')").fetchone()['c'],
    }
    reports = db.execute("SELECT r.*, a.title as ad_title, u.first_name as rname FROM reports r JOIN ads a ON r.ad_id=a.id LEFT JOIN users u ON r.reporter_id=u.id WHERE r.status='pending' ORDER BY r.created_at DESC LIMIT 20").fetchall()
    recent_ads = db.execute("SELECT a.*, u.first_name as seller FROM ads a JOIN users u ON a.user_id=u.id ORDER BY a.created_at DESC LIMIT 15").fetchall()
    recent_users = db.execute("""SELECT u.*, (SELECT COUNT(*) as c FROM ads WHERE user_id=u.id) as ac,
        (SELECT ip_address FROM ip_accounts WHERE phone=u.phone ORDER BY id DESC LIMIT 1) as ip
        FROM users u ORDER BY u.created_at DESC LIMIT 10""").fetchall()
    top_vil = db.execute("SELECT village, COUNT(*) as cnt FROM ads WHERE village!='' GROUP BY village ORDER BY cnt DESC LIMIT 10").fetchall()
    support_msgs = db.execute("SELECT s.*, u.first_name as uname FROM support_messages s JOIN users u ON s.user_id=u.id WHERE s.reply='' ORDER BY s.created_at DESC").fetchall()
    # آدرس‌های IP که بیش از یک حساب از آن‌ها ثبت‌نام شده (برای شناسایی حساب‌های تکراری)
    shared_ips = db.execute("""SELECT ip_address, COUNT(*) as cnt FROM ip_accounts
        GROUP BY ip_address HAVING cnt>1 ORDER BY cnt DESC LIMIT 10""").fetchall()
    return render_template('owner.html', stats=stats, reports=reports, recent_ads=recent_ads, recent_users=recent_users, top_vil=top_vil, support_msgs=support_msgs, shared_ips=shared_ips)

@app.route('/modir/users')
@owner_req
def owner_users():
    db = get_db()
    users = db.execute("""SELECT u.*, (SELECT COUNT(*) as c FROM ads WHERE user_id=u.id) as ac,
        (SELECT ip_address FROM ip_accounts WHERE phone=u.phone ORDER BY id DESC LIMIT 1) as ip
        FROM users u ORDER BY u.created_at DESC""").fetchall()
    return render_template('owner_users.html', users=users)

@app.route('/modir/ads')
@owner_req
def owner_ads():
    db = get_db()
    ads = db.execute("SELECT a.*, u.first_name as seller FROM ads a JOIN users u ON a.user_id=u.id ORDER BY a.created_at DESC").fetchall()
    return render_template('owner_ads.html', ads=ads)

@app.route('/modir/reports')
@owner_req
def owner_reports():
    db = get_db()
    reports = db.execute("SELECT r.*, a.title as ad_title, u.first_name as rname FROM reports r JOIN ads a ON r.ad_id=a.id LEFT JOIN users u ON r.reporter_id=u.id ORDER BY r.created_at DESC").fetchall()
    return render_template('owner_reports.html', reports=reports)

@app.route('/modir/support')
@owner_req
def owner_support():
    db = get_db()
    msgs = db.execute("SELECT s.*, u.first_name as uname FROM support_messages s JOIN users u ON s.user_id=u.id ORDER BY s.created_at DESC").fetchall()
    return render_template('owner_support.html', messages=msgs)

@app.route('/modir/support/<int:sid>/reply', methods=['POST'])
@owner_req
def owner_reply(sid):
    db = get_db()
    reply = request.form.get('reply','').strip()
    if reply:
        db.execute("UPDATE support_messages SET reply=?, replied_at=datetime('now','localtime') WHERE id=?",(reply,sid))
        target=db.execute("SELECT user_id FROM support_messages WHERE id=?",(sid,)).fetchone()
        if target: create_notification(db,target['user_id'],'support','پاسخ جدید پشتیبانی',reply,url_for('support'))
        db.commit(); flash('پاسخ ارسال شد ✅','success')
    return redirect(url_for('owner_support'))

@app.route('/modir/ban/<int:uid>', methods=['POST'])
@owner_req
def owner_ban(uid):
    db = get_db(); db.execute("UPDATE users SET is_banned=1 WHERE id=?",(uid,)); db.commit()
    return redirect(url_for('owner_users'))

@app.route('/modir/unban/<int:uid>', methods=['POST'])
@owner_req
def owner_unban(uid):
    db = get_db(); db.execute("UPDATE users SET is_banned=0 WHERE id=?",(uid,)); db.commit()
    return redirect(url_for('owner_users'))

@app.route('/modir/ad/<int:aid>/delete', methods=['POST'])
@owner_req
def owner_del_ad(aid):
    db = get_db(); db.execute("DELETE FROM ads WHERE id=?",(aid,)); db.commit()
    return redirect(url_for('owner_ads'))

@app.route('/modir/report/<int:rid>/resolve', methods=['POST'])
@owner_req
def owner_resolve(rid):
    db = get_db(); action = request.form.get('action','dismiss')
    if action == 'delete_ad':
        r = db.execute("SELECT ad_id FROM reports WHERE id=?",(rid,)).fetchone()
        if r: db.execute("DELETE FROM ads WHERE id=?",(r['ad_id'],))
    elif action == 'ban_user':
        r = db.execute("SELECT ad_id FROM reports WHERE id=?",(rid,)).fetchone()
        if r:
            a = db.execute("SELECT user_id FROM ads WHERE id=?",(r['ad_id'],)).fetchone()
            if a: db.execute("UPDATE users SET is_banned=1 WHERE id=?",(a['user_id'],))
    db.execute("UPDATE reports SET status='resolved' WHERE id=?",(rid,)); db.commit()
    return redirect(url_for('owner_reports'))

@app.route('/modir/featured/<int:aid>', methods=['POST'])
@owner_req
def owner_featured(aid):
    db = get_db(); ad = db.execute("SELECT is_featured FROM ads WHERE id=?",(aid,)).fetchone()
    if ad: db.execute("UPDATE ads SET is_featured=? WHERE id=?",(0 if ad['is_featured'] else 1, aid)); db.commit()
    return redirect(url_for('owner_ads'))

# ====== مدیریت دستیار هوشمند: درخواست‌ها، گزارش‌ها، مترادف‌ها، تنظیمات ======
@app.route('/modir/assistant')
@owner_req
def owner_assistant():
    db = get_db()
    _expire_needs(db)
    active_needs = db.execute("SELECT n.*, u.first_name as uname, u.phone as uphone FROM needs n JOIN users u ON n.user_id=u.id WHERE n.status='active' ORDER BY n.created_at DESC").fetchall()
    expired_needs = db.execute("SELECT n.*, u.first_name as uname FROM needs n JOIN users u ON n.user_id=u.id WHERE n.status='expired' ORDER BY n.created_at DESC LIMIT 30").fetchall()
    reports = db.execute("SELECT r.*, n.title as need_title FROM need_reports r JOIN needs n ON r.need_id=n.id WHERE r.status='pending' ORDER BY r.created_at DESC").fetchall()
    synonyms = db.execute("SELECT * FROM synonyms ORDER BY canonical").fetchall()
    settings = {k: get_setting(k) for k in DEFAULT_SETTINGS}
    return render_template('owner_assistant.html', active_needs=active_needs, expired_needs=expired_needs,
        reports=reports, synonyms=synonyms, settings=settings)

@app.route('/modir/assistant/settings', methods=['POST'])
@owner_req
def owner_assistant_settings():
    for key in DEFAULT_SETTINGS:
        val = request.form.get(key, '').strip()
        if val.isdigit() and int(val) > 0:
            set_setting(key, val)
    flash('تنظیمات دستیار بروزرسانی شد ✅','success')
    return redirect(url_for('owner_assistant'))

@app.route('/modir/synonyms/add', methods=['POST'])
@owner_req
def owner_synonym_add():
    canonical = request.form.get('canonical','').strip()
    variant = request.form.get('variant','').strip()
    if canonical and variant:
        db = get_db()
        try:
            db.execute("INSERT INTO synonyms (canonical,variant) VALUES (?,?)",(canonical, variant))
            db.commit()
            flash('مترادف اضافه شد ✅','success')
        except sqlite3.IntegrityError:
            flash('این کلمه قبلاً به‌عنوان مترادف ثبت شده','error')
    return redirect(url_for('owner_assistant'))

@app.route('/modir/synonyms/<int:sid>/delete', methods=['POST'])
@owner_req
def owner_synonym_delete(sid):
    db = get_db(); db.execute("DELETE FROM synonyms WHERE id=?",(sid,)); db.commit()
    return redirect(url_for('owner_assistant'))

@app.route('/modir/needs/<int:need_id>/delete', methods=['POST'])
@owner_req
def owner_need_delete(need_id):
    db = get_db(); db.execute("DELETE FROM needs WHERE id=?",(need_id,)); db.commit()
    flash('درخواست حذف شد','success')
    return redirect(url_for('owner_assistant'))

@app.route('/modir/needs/report/<int:rid>/resolve', methods=['POST'])
@owner_req
def owner_need_report_resolve(rid):
    db = get_db()
    action = request.form.get('action','dismiss')
    r = db.execute("SELECT need_id FROM need_reports WHERE id=?",(rid,)).fetchone()
    if r and action == 'delete_need':
        db.execute("DELETE FROM needs WHERE id=?",(r['need_id'],))
    db.execute("UPDATE need_reports SET status='resolved' WHERE id=?",(rid,))
    db.commit()
    return redirect(url_for('owner_assistant'))

@app.route('/modir/logout')
def owner_logout():
    session.pop('is_owner', None); return redirect(url_for('index'))


def _refresh_chat_preview(db,chat_id):
    row=db.execute("SELECT content,msg_type,created_at FROM messages WHERE chat_id=? ORDER BY datetime(created_at) DESC,id DESC LIMIT 1",(chat_id,)).fetchone()
    if row:
        label=row['content'] if row['msg_type']=='text' else '[تصویر]'
        db.execute("UPDATE chats SET last_message=?,last_message_at=? WHERE id=?",(label,row['created_at'],chat_id))
    else:
        db.execute("UPDATE chats SET last_message='' WHERE id=?",(chat_id,))

# ====== MESSAGE DELETE/EDIT ======
@app.route('/chat/message/<int:mid>/delete', methods=['POST'])
@login_req
def delete_message(mid):
    db = get_db()
    msg = db.execute("SELECT * FROM messages WHERE id=? AND (sender_id=? OR receiver_id=?)",
                     (mid, session['user_id'], session['user_id'])).fetchone()
    if msg:
        db.execute("DELETE FROM messages WHERE id=?", (mid,))
        _refresh_chat_preview(db,msg['chat_id'])
        db.commit()
    return jsonify({'status': 'ok'})

@app.route('/chat/message/<int:mid>/edit', methods=['POST'])
@login_req
def edit_message(mid):
    db = get_db()
    msg = db.execute("SELECT * FROM messages WHERE id=? AND sender_id=?",
                     (mid, session['user_id'])).fetchone()
    if not msg:
        return jsonify({'status': 'error', 'msg': 'پیام یافت نشد'})
    content = request.form.get('content', '').strip()
    if not content:
        return jsonify({'status': 'error', 'msg': 'پیام خالی'})
    if has_banned(content):
        return jsonify({'status': 'error', 'msg': 'پیام نامناسب'})
    db.execute("UPDATE messages SET content=? WHERE id=?", (content, mid))
    _refresh_chat_preview(db,msg['chat_id'])
    db.commit()
    return jsonify({'status': 'ok'})

@app.route('/chat/c/<int:chat_id>/delete', methods=['POST'])
@login_req
def delete_chat(chat_id):
    db=get_db(); uid=session['user_id']
    if not db.execute("SELECT id FROM chats WHERE id=? AND (user1_id=? OR user2_id=?)",(chat_id,uid,uid)).fetchone(): abort(404)
    db.execute("DELETE FROM messages WHERE chat_id=?",(chat_id,))
    db.execute("DELETE FROM chats WHERE id=?",(chat_id,)); db.commit()
    flash('فقط همین گفتگو حذف شد','info')
    return redirect(url_for('chat_list'))

# ====== ERRORS ======
@app.errorhandler(404)
def e404(e): return render_template('404.html'), 404
@app.errorhandler(413)
def e413(e): flash('حجم کل فایل‌های ارسالی بیش از حد مجاز است (حداکثر ۳۰ مگابایت مجموع عکس‌ها)','error'); return redirect(request.referrer or url_for('index'))
@app.errorhandler(400)
def e400(e): return render_template('error.html', code=400, message='درخواست نامعتبر بود. صفحه را رفرش کرده و دوباره تلاش کنید.'), 400
@app.errorhandler(500)
def e500(e):
    # هرگز جزئیات فنی خطا (stack trace) را برای کاربر نمایش نده
    return render_template('error.html', code=500, message='مشکلی در سرور رخ داده است. لطفاً دوباره تلاش کنید.'), 500

@app.route('/static/uploads/<path:fn>')
def uploaded(fn): return send_from_directory(UPLOAD, fn)
@app.route('/static/uploads/chat/<path:filename>')
def chat_file(filename): return send_from_directory(CHAT_UPLOAD, filename)

init_db()  # اطمینان از وجود جداول/ایندکس‌های جدید، چه با اجرای مستقیم و چه با WSGI/gunicorn

if __name__ == '__main__':
    if IS_PRODUCTION and not OWNER_PASS:
        print("⚠️  هشدار امنیتی: در محیط تولید (production) هستید ولی OWNER_PASSWORD در .env تنظیم نشده و از رمز پیش‌فرض استفاده می‌شود!")
    debug_mode = os.environ.get('FLASK_DEBUG', 'false' if IS_PRODUCTION else 'true').lower() == 'true'
    host = os.environ.get('HOST', '0.0.0.0')
    port = int(os.environ.get('PORT', 5000))
    print("="*50)
    print("  🌾 روستایار - بازارچه روستاهای سرخس")
    print(f"  در حال اجرا روی http://{host}:{port}  (debug={debug_mode})")
    print("  پنل مالک: /modir/login")
    print("  پنل ادمین: /admin/login")
    print("="*50)
    app.run(host=host, port=port, debug=debug_mode)
