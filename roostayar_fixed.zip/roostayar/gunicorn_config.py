"""
تنظیمات Gunicorn برای اجرای روستایار در محیط تولید (production)
اجرا: gunicorn -c gunicorn_config.py app:app
"""
import os

bind = f"127.0.0.1:{os.environ.get('PORT', 8000)}"
workers = 3
threads = 2
timeout = 60
