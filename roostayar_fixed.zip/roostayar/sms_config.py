# تنظیمات پیامک
# برای تست: کد در صفحه نمایش داده می‌شود
# برای واقعی: کلید API را وارد کنید

# کاوه‌نگار (kavenegar.com) - ۱۰ پیامک رایگان
KAVENEGAR_KEY = ''

# اس‌ام‌اس (sms.ir) - ۱۰ پیامک رایگان
SMS_IR_KEY = ''

# قاصدک (ghasedak.me)
GHASEDAK_KEY = ''

# کدام سرویس فعال باشد؟
# خالی بگذارید = حالت تست (کد در صفحه نمایش)
# 'kavenegar' یا 'sms_ir' یا 'ghasedak'
ACTIVE_PROVIDER = ''
